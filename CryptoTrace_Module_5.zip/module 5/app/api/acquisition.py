from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.blockchain.mock import MockBlockchainProvider
from app.services.acquisition import BlockchainDataAcquisitionService

router = APIRouter(prefix="/api")

@router.post("/wallets/{address}/transactions/sync")
def sync(address: str, db: Session = Depends(get_db)):
    result = BlockchainDataAcquisitionService(
        MockBlockchainProvider(), "mock"
    ).fetch_wallet_activity(address, "ethereum")
    return {
        "address": address,
        "complete": result["complete"],
        "native_count": len(result["native"].records),
        "token_transfer_count": len(result["token_transfers"].records),
    }

@router.get("/wallets/{address}/transactions")
def list_transactions(address: str, db: Session = Depends(get_db)):
    from sqlalchemy import select
    from app.models import Transaction
    rows = db.scalars(
        select(Transaction)
        .where((Transaction.sender == address) | (Transaction.receiver == address))
        .order_by(Transaction.block_number, Transaction.transaction_hash)
    ).all()
    return {"items": rows, "complete": True}
