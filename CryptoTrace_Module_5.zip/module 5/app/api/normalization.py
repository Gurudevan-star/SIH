from fastapi import APIRouter
from app.services.normalization import TransactionNormalizationService

router = APIRouter(prefix="/api")

@router.post("/transactions/normalize")
def normalize(payload: dict):
    rows = TransactionNormalizationService().normalize(
        payload.get("records", []),
        payload.get("network", "ethereum"),
        payload.get("provider_name", "api"),
    )
    return {"items": [row.__dict__ for row in rows]}
