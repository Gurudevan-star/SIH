from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.core.config import get_settings
from app.core.database import get_db
from app.schemas.common import WalletValidationRequest, WalletValidationResponse
from app.services.wallet import WalletValidationService
from app.blockchain.evm import EVMBlockchainProvider

router = APIRouter(prefix="/api")

@router.post("/wallets/validate", response_model=WalletValidationResponse)
def validate_wallet(data: WalletValidationRequest, db: Session = Depends(get_db)):
    settings = get_settings()
    provider = EVMBlockchainProvider(settings.evm_rpc_urls)
    return WalletValidationService(db, provider, settings.supported_network_set).validate(data)
