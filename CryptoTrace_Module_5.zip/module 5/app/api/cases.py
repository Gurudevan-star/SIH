from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models import Case, CaseWallet, Wallet
from app.schemas.common import (
    CaseCreate, CaseUpdate, CaseResponse,
    InvestigationCreate, InvestigationResponse, InvestigationStatusResponse
)
from app.services.investigation import CaseService, InvestigationService

router = APIRouter(prefix="/api")

@router.post("/cases", response_model=CaseResponse)
def create_case(data: CaseCreate, db: Session = Depends(get_db)):
    return CaseService(db).create(data)

@router.get("/cases", response_model=list[CaseResponse])
def list_cases(db: Session = Depends(get_db), limit: int = 100, offset: int = 0):
    return list(db.scalars(select(Case).offset(offset).limit(limit)).all())

@router.get("/cases/{case_id}", response_model=CaseResponse)
def get_case(case_id: UUID, db: Session = Depends(get_db)):
    obj = db.get(Case, case_id)
    if not obj:
        raise HTTPException(404, "case not found")
    return obj

@router.put("/cases/{case_id}", response_model=CaseResponse)
def update_case(case_id: UUID, data: CaseUpdate, db: Session = Depends(get_db)):
    return CaseService(db).update(case_id, data)

@router.post("/investigations", response_model=InvestigationResponse)
def create_investigation(data: InvestigationCreate, db: Session = Depends(get_db)):
    return InvestigationService(db).create(data)

@router.get("/investigations/{id}", response_model=InvestigationResponse)
def get_investigation(id: UUID, db: Session = Depends(get_db)):
    return InvestigationService(db).get(id)

@router.get("/investigations/{id}/status", response_model=InvestigationStatusResponse)
def investigation_status(id: UUID, db: Session = Depends(get_db)):
    return InvestigationService(db).status(id)

@router.post("/cases/{case_id}/wallets/{wallet_id}")
def associate_wallet(case_id: UUID, wallet_id: UUID, db: Session = Depends(get_db)):
    if not db.get(Case, case_id):
        raise HTTPException(404, "case not found")
    if not db.get(Wallet, wallet_id):
        raise HTTPException(404, "wallet not found")
    existing = db.scalar(select(CaseWallet).where(
        CaseWallet.case_id == case_id,
        CaseWallet.wallet_id == wallet_id
    ))
    if existing:
        return {"id": str(existing.id), "status": "already_associated"}
    link = CaseWallet(case_id=case_id, wallet_id=wallet_id)
    db.add(link)
    db.commit()
    db.refresh(link)
    return {"id": str(link.id), "status": "associated"}
