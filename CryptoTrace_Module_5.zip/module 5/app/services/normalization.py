from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from app.models import QualityFlag

@dataclass
class NormalizedTokenTransfer:
    transaction_hash: str
    network: str
    token_contract: str
    sender: str
    receiver: str
    raw_amount: Decimal
    normalized_amount: Decimal | None
    token_decimals: int | None
    provider_name: str | None
    raw_record_reference: str | None
    quality_flag: str

@dataclass
class NormalizedTransaction:
    network: str
    transaction_hash: str
    block_number: int | None
    block_timestamp: datetime | None
    sender: str | None
    receiver: str | None
    asset: str | None
    token_contract: str | None
    raw_amount: Decimal | None
    normalized_amount: Decimal | None
    token_decimals: int | None
    status: str | None
    gas_used: Decimal | None
    gas_price: Decimal | None
    provider_name: str | None
    provider_request_reference: str | None
    raw_record_reference: str | None
    retrieved_at: datetime
    quality_flag: str
    token_transfers: list[NormalizedTokenTransfer]

class TransactionNormalizationService:
    def normalize(self, records: list[dict], network: str, provider_name="provider", retrieved_at=None):
        retrieved_at = retrieved_at or datetime.now(timezone.utc)
        output = []

        for record in records:
            flag = QualityFlag.COMPLETE.value
            tx_hash = record.get("transaction_hash") or record.get("hash") or record.get("txHash")
            sender = record.get("sender") or record.get("from")
            receiver = record.get("receiver") or record.get("to")
            block = record.get("block_number") if record.get("block_number") is not None else record.get("blockNumber")
            raw = record.get("raw_amount") if record.get("raw_amount") is not None else record.get("value")
            decimals_value = record.get("token_decimals") if record.get("token_decimals") is not None else record.get("decimals")

            if not tx_hash or sender is None or receiver is None:
                flag = QualityFlag.MALFORMED.value

            try:
                raw_decimal = Decimal(str(raw)) if raw is not None else None
            except (InvalidOperation, ValueError):
                raw_decimal = None
                flag = QualityFlag.MALFORMED.value

            try:
                decimals = int(decimals_value) if decimals_value is not None else None
            except (TypeError, ValueError):
                decimals = None
                flag = QualityFlag.UNKNOWN_METADATA.value

            normalized = None
            if raw_decimal is not None and decimals is not None:
                normalized = raw_decimal / (Decimal(10) ** decimals)
            elif raw_decimal is not None and flag == QualityFlag.COMPLETE.value:
                flag = QualityFlag.UNKNOWN_METADATA.value

            timestamp = record.get("block_timestamp") or record.get("timestamp")
            if isinstance(timestamp, (int, float)):
                timestamp = datetime.fromtimestamp(timestamp, tz=timezone.utc)

            output.append(NormalizedTransaction(
                network=network.lower(),
                transaction_hash=tx_hash,
                block_number=int(block) if block is not None else None,
                block_timestamp=timestamp,
                sender=sender.lower() if isinstance(sender, str) else sender,
                receiver=receiver.lower() if isinstance(receiver, str) else receiver,
                asset=record.get("asset") or record.get("symbol"),
                token_contract=record.get("token_contract") or record.get("contractAddress"),
                raw_amount=raw_decimal,
                normalized_amount=normalized,
                token_decimals=decimals,
                status=record.get("status") or record.get("txreceipt_status"),
                gas_used=Decimal(str(record["gas_used"])) if record.get("gas_used") is not None else None,
                gas_price=Decimal(str(record["gas_price"])) if record.get("gas_price") is not None else None,
                provider_name=provider_name,
                provider_request_reference=record.get("request_reference"),
                raw_record_reference=record.get("raw_record_reference") or record.get("id"),
                retrieved_at=retrieved_at,
                quality_flag=flag,
                token_transfers=[],
            ))
        return output
