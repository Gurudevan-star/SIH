from dataclasses import dataclass
from datetime import datetime, timezone
from app.blockchain.provider import BlockchainProvider

@dataclass
class AcquisitionPage:
    records: list[dict]
    complete: bool
    provider_name: str
    retrieved_at: datetime
    request_reference: str | None

class BlockchainDataAcquisitionService:
    def __init__(self, provider: BlockchainProvider, provider_name="provider", max_retries=2):
        self.provider = provider
        self.provider_name = provider_name
        self.max_retries = max_retries

    def _fetch(self, method, address, network):
        page = None
        records = []
        seen = set()
        complete = True
        safety = 0

        while True:
            for attempt in range(self.max_retries + 1):
                try:
                    response = method(address, network, page_token=page, page_size=100)
                    break
                except Exception:
                    if attempt >= self.max_retries:
                        raise

            for record in response.get("records", []):
                key = (
                    record.get("transaction_hash") or record.get("hash") or record.get("txHash"),
                    record.get("log_index"),
                )
                if key not in seen:
                    seen.add(key)
                    records.append(record)

            complete = complete and bool(response.get("complete", True))
            page = response.get("next_page")
            safety += 1
            if not page:
                break
            if safety > 1000:
                raise RuntimeError("pagination safety limit exceeded")

        return AcquisitionPage(
            records=records,
            complete=complete,
            provider_name=self.provider_name,
            retrieved_at=datetime.now(timezone.utc),
            request_reference=None,
        )

    def fetch_wallet_activity(self, address, network):
        native = self._fetch(self.provider.get_native_transactions, address, network)
        tokens = self._fetch(self.provider.get_token_transfers, address, network)
        return {
            "native": native,
            "token_transfers": tokens,
            "complete": native.complete and tokens.complete,
        }
