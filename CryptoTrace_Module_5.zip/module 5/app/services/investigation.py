from sqlalchemy import select
from sqlalchemy.orm import Session
from fastapi import HTTPException
from app.models import AuditLog, Case, Investigation, InvestigationState, Wallet
from app.schemas.common import CaseCreate, CaseUpdate, InvestigationCreate

SUPPORTED_NETWORKS = {"ethereum", "polygon", "arbitrum", "sepolia"}

class CaseService:
    def __init__(self, db: Session):
        self.db = db

    def create(self, data: CaseCreate):
        if self.db.scalar(select(Case).where(Case.case_number == data.case_number)):
            raise HTTPException(409, "case_number already exists")
        obj = Case(**data.model_dump())
        self.db.add(obj)
        self.db.flush()
        self.db.add(AuditLog(
            case_id=obj.id, actor="api", action="CASE_CREATED",
            entity_type="Case", entity_id=str(obj.id)
        ))
        self.db.commit()
        self.db.refresh(obj)
        return obj

    def update(self, case_id, data: CaseUpdate):
        obj = self.db.get(Case, case_id)
        if not obj:
            raise HTTPException(404, "case not found")
        for key, value in data.model_dump(exclude_unset=True).items():
            setattr(obj, key, value)
        self.db.add(AuditLog(
            case_id=obj.id, actor="api", action="CASE_UPDATED",
            entity_type="Case", entity_id=str(obj.id)
        ))
        self.db.commit()
        self.db.refresh(obj)
        return obj

class InvestigationService:
    def __init__(self, db: Session):
        self.db = db

    def create(self, data: InvestigationCreate):
        network = data.network.lower()
        if network not in SUPPORTED_NETWORKS:
            raise HTTPException(400, "unsupported blockchain network")
        if not self.db.get(Case, data.case_id):
            raise HTTPException(404, "case not found")
        if not self.db.get(Wallet, data.source_wallet_id):
            raise HTTPException(404, "source wallet not found")

        configuration = {
            "maximum_hops": data.maximum_hops,
            "minimum_transfer_threshold": str(data.minimum_transfer_threshold),
            "time_window_start": data.time_window_start.isoformat() if data.time_window_start else None,
            "time_window_end": data.time_window_end.isoformat() if data.time_window_end else None,
            "asset_filters": data.asset_filters,
            "monitoring_preference": data.monitoring_preference,
        }
        obj = Investigation(
            case_id=data.case_id,
            source_wallet_id=data.source_wallet_id,
            network=network,
            state=InvestigationState.QUEUED.value,
            configuration=configuration,
            progress_percent=0,
        )
        self.db.add(obj)
        self.db.commit()
        self.db.refresh(obj)
        return obj

    def get(self, investigation_id):
        obj = self.db.get(Investigation, investigation_id)
        if not obj:
            raise HTTPException(404, "investigation not found")
        return obj

    def status(self, investigation_id):
        obj = self.get(investigation_id)
        return {
            "id": obj.id,
            "state": obj.state,
            "progress_percent": obj.progress_percent,
            "error_message": obj.error_message,
        }
