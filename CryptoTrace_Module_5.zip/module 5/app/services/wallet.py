from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models import Wallet
from app.schemas.common import WalletValidationRequest
from app.blockchain.provider import BlockchainProvider
from app.blockchain.errors import ProviderError

class WalletValidationService:
    def __init__(self, db: Session, provider: BlockchainProvider, supported_networks: set[str]):
        self.db = db
        self.provider = provider
        self.supported_networks = supported_networks

    def validate(self, data: WalletValidationRequest):
        network = data.network.lower()
        if network not in self.supported_networks:
            raise HTTPException(400, "unsupported blockchain network")

        try:
            result = self.provider.validate_address(data.address, network)
        except ProviderError as exc:
            raise HTTPException(503, f"{exc.code.value}: {exc.message}") from exc

        if result["address_valid"]:
            normalized = result["address"].lower()
            existing = self.db.scalar(select(Wallet).where(
                Wallet.network == network, Wallet.address == normalized
            ))
            if not existing:
                self.db.add(Wallet(
                    network=network,
                    address=normalized,
                    checksum_address=result.get("checksum_address"),
                    address_type=result.get("address_type", "UNKNOWN"),
                    provider_metadata=result.get("provider_metadata"),
                ))
                self.db.commit()
        return result
