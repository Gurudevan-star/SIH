# CryptoTrace — Module 5

Current stage: Module 5

This repository snapshot is cumulative: it contains the foundation and all modules through Module 5.

## Setup
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
createdb cryptotrace
export PYTHONPATH=.
```

## Database migration
The canonical SQLAlchemy metadata is in `app/models/domain.py`.
Generate and commit the first real Alembic revision:
```bash
alembic revision --autogenerate -m "create canonical cryptotrace domain"
alembic upgrade head
```

Do not rename the `app` package or the canonical entity names.

## Run
```bash
uvicorn app.main:app --reload
```
Open `/docs`.

## Tests
```bash
pytest
```
