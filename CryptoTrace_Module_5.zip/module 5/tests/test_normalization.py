from decimal import Decimal
from app.services.normalization import TransactionNormalizationService

def test_provider_field_variants_and_decimal():
    rows = TransactionNormalizationService().normalize([{
        "hash": "0xabc",
        "from": "0x" + "1" * 40,
        "to": "0x" + "2" * 40,
        "value": "123456789",
        "decimals": 6,
        "blockNumber": "42",
    }], "ethereum", "mock")

    assert rows[0].normalized_amount == Decimal("123.456789")
    assert rows[0].block_number == 42
