# Module 5
## Transaction Normalization

This is the Module 5 stage of the cumulative CryptoTrace backend.
Later modules extend the same canonical persistence model.
