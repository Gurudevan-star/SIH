from decimal import Decimal
from app.models import Case, Wallet, Transaction

def test_decimal_is_exact():
    c = Case(case_number="T-1", title="Test", reported_amount=Decimal("1.234567890123456789"))
    assert c.reported_amount == Decimal("1.234567890123456789")

def test_transaction_hash_separate_from_uuid():
    t = Transaction(network="ethereum", transaction_hash="0xabc")
    assert t.transaction_hash == "0xabc"
    assert t.id is None
