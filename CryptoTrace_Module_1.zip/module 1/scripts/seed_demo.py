from app.core.database import SessionLocal
from app.models import Case, Wallet, CaseWallet

def main():
    db = SessionLocal()
    try:
        case = db.query(Case).filter_by(case_number="DEMO-001").first()
        if not case:
            case = Case(
                case_number="DEMO-001",
                title="CryptoTrace Demo Case",
                description="Development-only seed data",
                reported_amount=0,
                currency="ETH",
            )
            db.add(case)
            db.flush()

        wallet = db.query(Wallet).filter_by(
            network="sepolia",
            address="0x0000000000000000000000000000000000000001"
        ).first()
        if not wallet:
            wallet = Wallet(
                network="sepolia",
                address="0x0000000000000000000000000000000000000001",
                checksum_address="0x0000000000000000000000000000000000000001",
                address_type="EOA",
            )
            db.add(wallet)
            db.flush()

        if not db.query(CaseWallet).filter_by(case_id=case.id, wallet_id=wallet.id).first():
            db.add(CaseWallet(case_id=case.id, wallet_id=wallet.id))
        db.commit()
        print("Demo seed complete.")
    finally:
        db.close()

if __name__ == "__main__":
    main()
