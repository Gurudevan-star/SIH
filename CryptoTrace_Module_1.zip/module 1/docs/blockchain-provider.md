# Blockchain Provider Contract

The `BlockchainProvider` interface isolates blockchain/provider details from the application.

Required methods:
- validate_address
- get_native_transactions
- get_token_transfers
- get_block_timestamp
- get_latest_block

Supported provider error codes:
RATE_LIMITED, TIMEOUT, PROVIDER_UNAVAILABLE, INVALID_ADDRESS,
NOT_SUPPORTED, UNKNOWN_PROVIDER_ERROR.

Secrets such as RPC URLs and API keys are configured through environment variables.
