# CryptoTrace Canonical Data Model

Canonical entities:
Case, Wallet, CaseWallet, Investigation, Transaction, TokenTransfer, GraphNode, GraphEdge,
WalletCluster, ClusterMember, Exchange, ExchangeAddress, IntelligenceSource, RiskAssessment,
RiskFactor, AttributionAssessment, MonitoringTarget, Alert, Evidence, InvestigationReport, AuditLog.

Persistence rules:
- Internal IDs are UUIDs.
- Blockchain transaction hashes are separate from internal IDs and unique per network.
- Wallet addresses are unique per network.
- Crypto amounts use PostgreSQL NUMERIC and Python Decimal.
- Timestamps are timezone-aware and intended to be UTC.
- Evidence foreign keys use RESTRICT to prevent accidental deletion.
- Later modules extend these entities instead of creating duplicate concepts.

Relationships:
Case -> CaseWallet -> Wallet
Case -> Investigation -> Wallet
Wallet -> Transaction -> TokenTransfer
GraphNode -> GraphEdge -> Transaction
WalletCluster -> ClusterMember -> Wallet
Exchange -> ExchangeAddress
RiskAssessment -> RiskFactor
MonitoringTarget -> Alert
Case -> Evidence
Investigation -> InvestigationReport
Case -> AuditLog
