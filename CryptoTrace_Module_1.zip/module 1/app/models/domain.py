import enum
import uuid
from decimal import Decimal
from datetime import datetime
from sqlalchemy import Boolean, CheckConstraint, DateTime, ForeignKey, Index, Integer, JSON, Numeric, String, Text, UniqueConstraint, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.core.database import Base

class InvestigationState(str, enum.Enum):
    DRAFT = "DRAFT"
    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"

class AddressType(str, enum.Enum):
    EOA = "EOA"
    CONTRACT = "CONTRACT"
    UNKNOWN = "UNKNOWN"

class QualityFlag(str, enum.Enum):
    COMPLETE = "COMPLETE"
    PARTIAL = "PARTIAL"
    MALFORMED = "MALFORMED"
    UNKNOWN_METADATA = "UNKNOWN_METADATA"

class BaseEntity(Base):
    __abstract__ = True
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)

class Case(BaseEntity):
    __tablename__ = "cases"
    case_number: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    reported_amount: Mapped[Decimal | None] = mapped_column(Numeric(78, 18))
    currency: Mapped[str | None] = mapped_column(String(32))
    wallets = relationship("CaseWallet", back_populates="case", cascade="all, delete-orphan")
    investigations = relationship("Investigation", back_populates="case")
    audit_logs = relationship("AuditLog", back_populates="case")
    __table_args__ = (CheckConstraint("reported_amount IS NULL OR reported_amount >= 0", name="ck_case_reported_amount_nonnegative"),)

class Wallet(BaseEntity):
    __tablename__ = "wallets"
    network: Mapped[str] = mapped_column(String(64), nullable=False)
    address: Mapped[str] = mapped_column(String(128), nullable=False)
    checksum_address: Mapped[str | None] = mapped_column(String(128))
    address_type: Mapped[str] = mapped_column(String(16), default=AddressType.UNKNOWN.value, nullable=False)
    provider_metadata: Mapped[dict | None] = mapped_column(JSON)
    case_links = relationship("CaseWallet", back_populates="wallet")
    investigations = relationship("Investigation", back_populates="source_wallet")
    transactions = relationship("Transaction", back_populates="wallet")
    __table_args__ = (
        UniqueConstraint("network", "address", name="uq_wallet_network_address"),
        Index("ix_wallet_network", "network"),
    )

class CaseWallet(BaseEntity):
    __tablename__ = "case_wallets"
    case_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("cases.id", ondelete="CASCADE"), nullable=False)
    wallet_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("wallets.id", ondelete="RESTRICT"), nullable=False)
    role: Mapped[str] = mapped_column(String(64), default="SUBJECT", nullable=False)
    case = relationship("Case", back_populates="wallets")
    wallet = relationship("Wallet", back_populates="case_links")
    __table_args__ = (UniqueConstraint("case_id", "wallet_id", name="uq_case_wallet"),)

class Investigation(BaseEntity):
    __tablename__ = "investigations"
    case_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("cases.id", ondelete="RESTRICT"), nullable=False)
    source_wallet_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("wallets.id", ondelete="RESTRICT"), nullable=False)
    network: Mapped[str] = mapped_column(String(64), nullable=False)
    state: Mapped[str] = mapped_column(String(32), default=InvestigationState.DRAFT.value, nullable=False)
    configuration: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    progress_percent: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    error_message: Mapped[str | None] = mapped_column(Text)
    case = relationship("Case", back_populates="investigations")
    source_wallet = relationship("Wallet", back_populates="investigations")
    __table_args__ = (
        CheckConstraint("progress_percent BETWEEN 0 AND 100", name="ck_investigation_progress"),
        Index("ix_investigation_case", "case_id"),
    )

class Transaction(BaseEntity):
    __tablename__ = "transactions"
    network: Mapped[str] = mapped_column(String(64), nullable=False)
    transaction_hash: Mapped[str] = mapped_column(String(128), nullable=False)
    wallet_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("wallets.id", ondelete="SET NULL"))
    sender: Mapped[str | None] = mapped_column(String(128))
    receiver: Mapped[str | None] = mapped_column(String(128))
    block_number: Mapped[int | None] = mapped_column(Integer)
    block_timestamp: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    asset: Mapped[str | None] = mapped_column(String(128))
    token_contract: Mapped[str | None] = mapped_column(String(128))
    raw_amount: Mapped[Decimal | None] = mapped_column(Numeric(78, 0))
    normalized_amount: Mapped[Decimal | None] = mapped_column(Numeric(78, 18))
    token_decimals: Mapped[int | None] = mapped_column(Integer)
    status: Mapped[str | None] = mapped_column(String(32))
    gas_used: Mapped[Decimal | None] = mapped_column(Numeric(78, 0))
    gas_price: Mapped[Decimal | None] = mapped_column(Numeric(78, 0))
    provider_name: Mapped[str | None] = mapped_column(String(128))
    provider_request_reference: Mapped[str | None] = mapped_column(String(512))
    raw_record_reference: Mapped[str | None] = mapped_column(String(512))
    retrieved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    quality_flag: Mapped[str] = mapped_column(String(32), default=QualityFlag.COMPLETE.value, nullable=False)
    wallet = relationship("Wallet", back_populates="transactions")
    token_transfers = relationship("TokenTransfer", back_populates="transaction", cascade="all, delete-orphan")
    outgoing_edges = relationship("GraphEdge", foreign_keys="GraphEdge.transaction_id", back_populates="transaction")
    __table_args__ = (
        UniqueConstraint("network", "transaction_hash", name="uq_transaction_network_hash"),
        Index("ix_transaction_sender", "network", "sender"),
        Index("ix_transaction_receiver", "network", "receiver"),
        Index("ix_transaction_block", "network", "block_number"),
    )

class TokenTransfer(BaseEntity):
    __tablename__ = "token_transfers"
    transaction_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("transactions.id", ondelete="RESTRICT"), nullable=False)
    network: Mapped[str] = mapped_column(String(64), nullable=False)
    token_contract: Mapped[str] = mapped_column(String(128), nullable=False)
    sender: Mapped[str] = mapped_column(String(128), nullable=False)
    receiver: Mapped[str] = mapped_column(String(128), nullable=False)
    raw_amount: Mapped[Decimal] = mapped_column(Numeric(78, 0), nullable=False)
    normalized_amount: Mapped[Decimal | None] = mapped_column(Numeric(78, 18))
    token_decimals: Mapped[int | None] = mapped_column(Integer)
    provider_name: Mapped[str | None] = mapped_column(String(128))
    raw_record_reference: Mapped[str | None] = mapped_column(String(512))
    transaction = relationship("Transaction", back_populates="token_transfers")
    __table_args__ = (UniqueConstraint("transaction_id", "token_contract", "sender", "receiver", "raw_amount", name="uq_token_transfer_identity"),)

class GraphNode(BaseEntity):
    __tablename__ = "graph_nodes"
    network: Mapped[str] = mapped_column(String(64), nullable=False)
    node_key: Mapped[str] = mapped_column(String(256), nullable=False)
    node_type: Mapped[str] = mapped_column(String(64), nullable=False)
    wallet_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("wallets.id", ondelete="SET NULL"))
    __table_args__ = (UniqueConstraint("network", "node_key", name="uq_graph_node"),)

class GraphEdge(BaseEntity):
    __tablename__ = "graph_edges"
    network: Mapped[str] = mapped_column(String(64), nullable=False)
    source_node_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("graph_nodes.id", ondelete="RESTRICT"), nullable=False)
    target_node_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("graph_nodes.id", ondelete="RESTRICT"), nullable=False)
    transaction_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("transactions.id", ondelete="SET NULL"))
    asset: Mapped[str | None] = mapped_column(String(128))
    amount: Mapped[Decimal | None] = mapped_column(Numeric(78, 18))
    transaction = relationship("Transaction", back_populates="outgoing_edges")
    __table_args__ = (Index("ix_graph_edge_source", "source_node_id"), Index("ix_graph_edge_target", "target_node_id"))

class WalletCluster(BaseEntity):
    __tablename__ = "wallet_clusters"
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    method: Mapped[str | None] = mapped_column(String(128))
    confidence: Mapped[Decimal | None] = mapped_column(Numeric(10, 6))
    members = relationship("ClusterMember", back_populates="cluster", cascade="all, delete-orphan")

class ClusterMember(BaseEntity):
    __tablename__ = "cluster_members"
    cluster_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("wallet_clusters.id", ondelete="CASCADE"), nullable=False)
    wallet_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("wallets.id", ondelete="RESTRICT"), nullable=False)
    cluster = relationship("WalletCluster", back_populates="members")
    __table_args__ = (UniqueConstraint("cluster_id", "wallet_id", name="uq_cluster_member"),)

class Exchange(BaseEntity):
    __tablename__ = "exchanges"
    name: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    website: Mapped[str | None] = mapped_column(String(512))
    addresses = relationship("ExchangeAddress", back_populates="exchange", cascade="all, delete-orphan")

class ExchangeAddress(BaseEntity):
    __tablename__ = "exchange_addresses"
    exchange_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exchanges.id", ondelete="CASCADE"), nullable=False)
    network: Mapped[str] = mapped_column(String(64), nullable=False)
    address: Mapped[str] = mapped_column(String(128), nullable=False)
    source: Mapped[str | None] = mapped_column(String(255))
    exchange = relationship("Exchange", back_populates="addresses")
    __table_args__ = (UniqueConstraint("network", "address", name="uq_exchange_address_network"),)

class IntelligenceSource(BaseEntity):
    __tablename__ = "intelligence_sources"
    source_type: Mapped[str] = mapped_column(String(64), nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    reference: Mapped[str | None] = mapped_column(String(512))
    reliability: Mapped[Decimal | None] = mapped_column(Numeric(10, 6))
    metadata_json: Mapped[dict | None] = mapped_column("metadata", JSON)

class RiskAssessment(BaseEntity):
    __tablename__ = "risk_assessments"
    wallet_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("wallets.id", ondelete="RESTRICT"), nullable=False)
    score: Mapped[Decimal | None] = mapped_column(Numeric(10, 4))
    methodology_version: Mapped[str | None] = mapped_column(String(64))
    assessed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

class RiskFactor(BaseEntity):
    __tablename__ = "risk_factors"
    assessment_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("risk_assessments.id", ondelete="CASCADE"), nullable=False)
    factor_code: Mapped[str] = mapped_column(String(128), nullable=False)
    weight: Mapped[Decimal | None] = mapped_column(Numeric(10, 6))
    evidence_reference: Mapped[str | None] = mapped_column(String(512))

class AttributionAssessment(BaseEntity):
    __tablename__ = "attribution_assessments"
    wallet_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("wallets.id", ondelete="RESTRICT"), nullable=False)
    entity_type: Mapped[str | None] = mapped_column(String(64))
    entity_name: Mapped[str | None] = mapped_column(String(255))
    confidence: Mapped[Decimal | None] = mapped_column(Numeric(10, 6))
    source_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("intelligence_sources.id", ondelete="SET NULL"))

class MonitoringTarget(BaseEntity):
    __tablename__ = "monitoring_targets"
    wallet_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("wallets.id", ondelete="RESTRICT"), nullable=False)
    network: Mapped[str] = mapped_column(String(64), nullable=False)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    configuration: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)

class Alert(BaseEntity):
    __tablename__ = "alerts"
    monitoring_target_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("monitoring_targets.id", ondelete="SET NULL"))
    alert_type: Mapped[str] = mapped_column(String(64), nullable=False)
    severity: Mapped[str] = mapped_column(String(32), nullable=False)
    message: Mapped[str] = mapped_column(Text, nullable=False)
    triggered_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)

class Evidence(BaseEntity):
    __tablename__ = "evidence"
    case_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("cases.id", ondelete="RESTRICT"), nullable=False)
    evidence_type: Mapped[str] = mapped_column(String(64), nullable=False)
    source_reference: Mapped[str] = mapped_column(String(512), nullable=False)
    content_hash: Mapped[str | None] = mapped_column(String(128))
    evidence_metadata: Mapped[dict | None] = mapped_column("metadata", JSON)

class InvestigationReport(BaseEntity):
    __tablename__ = "investigation_reports"
    investigation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("investigations.id", ondelete="RESTRICT"), nullable=False)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    report_reference: Mapped[str | None] = mapped_column(String(512))
    content: Mapped[str | None] = mapped_column(Text)

class AuditLog(BaseEntity):
    __tablename__ = "audit_logs"
    case_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("cases.id", ondelete="SET NULL"))
    actor: Mapped[str] = mapped_column(String(255), nullable=False)
    action: Mapped[str] = mapped_column(String(128), nullable=False)
    entity_type: Mapped[str | None] = mapped_column(String(128))
    entity_id: Mapped[str | None] = mapped_column(String(128))
    details: Mapped[dict | None] = mapped_column(JSON)
    case = relationship("Case", back_populates="audit_logs")
