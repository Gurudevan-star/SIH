from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "CryptoTrace"
    environment: str = "development"
    database_url: str = "postgresql+psycopg://postgres:postgres@localhost:5432/cryptotrace"
    db_pool_size: int = 10
    db_max_overflow: int = 20
    default_network: str = "ethereum"
    supported_networks: str = "ethereum,polygon,arbitrum,sepolia"
    evm_rpc_urls: dict = {}
    explorer_api_keys: dict = {}
    max_hops: int = 20

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def supported_network_set(self) -> set[str]:
        return {x.strip().lower() for x in self.supported_networks.split(",") if x.strip()}

@lru_cache
def get_settings() -> Settings:
    return Settings()
