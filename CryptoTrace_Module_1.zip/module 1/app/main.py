from fastapi import FastAPI
from app.core.config import get_settings
from app.api.health import router as health_router

app = FastAPI(title=get_settings().app_name, version="1.0.0")
app.include_router(health_router)

for module_name, router_name in [
    ("app.api.cases", "router"),
    ("app.api.wallets", "router"),
    ("app.api.acquisition", "router"),
    ("app.api.normalization", "router"),
]:
    try:
        module = __import__(module_name, fromlist=[router_name])
        app.include_router(getattr(module, router_name))
    except ImportError:
        pass

@app.get("/")
def root():
    return {"application": get_settings().app_name, "status": "running"}
