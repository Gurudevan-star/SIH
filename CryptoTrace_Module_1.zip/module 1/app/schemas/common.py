from datetime import datetime
from decimal import Decimal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field

class ORMModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)

class CaseCreate(BaseModel):
    case_number: str = Field(min_length=1, max_length=64)
    title: str
    description: str | None = None
    reported_amount: Decimal | None = Field(default=None, ge=0)
    currency: str | None = None

class CaseUpdate(BaseModel):
    title: str | None = None
    description: str | None = None
    reported_amount: Decimal | None = Field(default=None, ge=0)
    currency: str | None = None

class CaseResponse(ORMModel):
    id: UUID
    case_number: str
    title: str
    description: str | None
    reported_amount: Decimal | None
    currency: str | None
    created_at: datetime
    updated_at: datetime

class WalletValidationRequest(BaseModel):
    address: str
    network: str

class WalletValidationResponse(BaseModel):
    address: str
    checksum_address: str | None
    network: str
    address_valid: bool
    address_type: str
    provider_metadata: dict | None = None

class InvestigationCreate(BaseModel):
    case_id: UUID
    source_wallet_id: UUID
    network: str
    maximum_hops: int = Field(default=3, ge=0, le=20)
    minimum_transfer_threshold: Decimal = Field(default=Decimal("0"), ge=0)
    time_window_start: datetime | None = None
    time_window_end: datetime | None = None
    asset_filters: list[str] = Field(default_factory=list)
    monitoring_preference: bool = False

class InvestigationResponse(ORMModel):
    id: UUID
    case_id: UUID
    source_wallet_id: UUID
    network: str
    state: str
    configuration: dict
    progress_percent: int
    error_message: str | None
    created_at: datetime
    updated_at: datetime

class InvestigationStatusResponse(BaseModel):
    id: UUID
    state: str
    progress_percent: int
    error_message: str | None
