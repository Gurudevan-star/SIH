from fastapi import APIRouter
from app.core.database import database_healthcheck
router = APIRouter()

@router.get("/api/health")
def health():
    ok = database_healthcheck()
    return {"status": "ok" if ok else "degraded", "database": "ok" if ok else "unavailable"}
