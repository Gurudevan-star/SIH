from datetime import datetime, timezone
from .provider import BlockchainProvider
from .errors import ProviderError, ProviderErrorCode

class MockBlockchainProvider(BlockchainProvider):
    def __init__(self, pages=None, fail=False, partial=False):
        self.pages = pages or []
        self.fail, self.partial = fail, partial

    def validate_address(self, address, network):
        if self.fail:
            raise ProviderError(ProviderErrorCode.PROVIDER_UNAVAILABLE, "mock failure")
        ok = address.startswith("0x") and len(address) == 42
        return {
            "address": address,
            "checksum_address": address,
            "network": network,
            "address_valid": ok,
            "address_type": "EOA" if ok else "UNKNOWN",
            "provider_metadata": {"provider": "mock"},
        }

    def get_native_transactions(self, address, network, page_token=None, page_size=100):
        if self.fail:
            raise ProviderError(ProviderErrorCode.TIMEOUT, "mock timeout")
        i = int(page_token or 0)
        data = self.pages[i] if i < len(self.pages) else []
        return {"records": data[:page_size], "next_page": str(i + 1) if i + 1 < len(self.pages) else None, "complete": not self.partial}

    def get_token_transfers(self, address, network, page_token=None, page_size=100):
        return self.get_native_transactions(address, network, page_token, page_size)

    def get_block_timestamp(self, block_number, network):
        return datetime.now(timezone.utc)

    def get_latest_block(self, network):
        return 999999
