from enum import Enum

class ProviderErrorCode(str, Enum):
    RATE_LIMITED = "RATE_LIMITED"
    TIMEOUT = "TIMEOUT"
    PROVIDER_UNAVAILABLE = "PROVIDER_UNAVAILABLE"
    INVALID_ADDRESS = "INVALID_ADDRESS"
    NOT_SUPPORTED = "NOT_SUPPORTED"
    UNKNOWN_PROVIDER_ERROR = "UNKNOWN_PROVIDER_ERROR"

class ProviderError(Exception):
    def __init__(self, code: ProviderErrorCode, message: str):
        self.code, self.message = code, message
        super().__init__(message)
