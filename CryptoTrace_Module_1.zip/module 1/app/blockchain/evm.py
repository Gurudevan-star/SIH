from web3 import Web3
from .provider import BlockchainProvider
from .errors import ProviderError, ProviderErrorCode

class EVMBlockchainProvider(BlockchainProvider):
    def __init__(self, rpc_urls: dict):
        self.rpc_urls = rpc_urls

    def _w3(self, network):
        url = self.rpc_urls.get(network)
        if not url:
            raise ProviderError(ProviderErrorCode.NOT_SUPPORTED, f"No RPC configured for {network}")
        try:
            return Web3(Web3.HTTPProvider(url, request_kwargs={"timeout": 15}))
        except Exception as exc:
            raise ProviderError(ProviderErrorCode.PROVIDER_UNAVAILABLE, str(exc)) from exc

    def validate_address(self, address, network):
        w3 = self._w3(network)
        if not Web3.is_address(address):
            return {
                "address": address, "checksum_address": None, "network": network,
                "address_valid": False, "address_type": "UNKNOWN", "provider_metadata": {}
            }
        checksum = w3.to_checksum_address(address)
        try:
            code = w3.eth.get_code(checksum)
            address_type = "CONTRACT" if code and code != b"\x00" else "EOA"
            return {
                "address": address, "checksum_address": checksum, "network": network,
                "address_valid": True, "address_type": address_type,
                "provider_metadata": {"provider": "evm-rpc"}
            }
        except Exception as exc:
            raise ProviderError(ProviderErrorCode.PROVIDER_UNAVAILABLE, str(exc)) from exc

    def get_native_transactions(self, *args, **kwargs):
        raise ProviderError(ProviderErrorCode.NOT_SUPPORTED, "Use an explorer/history adapter for transaction history")

    def get_token_transfers(self, *args, **kwargs):
        raise ProviderError(ProviderErrorCode.NOT_SUPPORTED, "Use an explorer/history adapter for token history")

    def get_block_timestamp(self, block_number, network):
        try:
            return self._w3(network).eth.get_block(block_number).timestamp
        except Exception as exc:
            raise ProviderError(ProviderErrorCode.PROVIDER_UNAVAILABLE, str(exc)) from exc

    def get_latest_block(self, network):
        try:
            return self._w3(network).eth.block_number
        except Exception as exc:
            raise ProviderError(ProviderErrorCode.PROVIDER_UNAVAILABLE, str(exc)) from exc
