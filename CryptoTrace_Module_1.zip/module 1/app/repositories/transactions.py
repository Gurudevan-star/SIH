from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models import Transaction
from .base import Repository

class TransactionRepository(Repository[Transaction]):
    def __init__(self, db: Session):
        super().__init__(db, Transaction)
    def get_by_hash(self, network, tx_hash):
        return self.db.scalar(select(Transaction).where(Transaction.network == network, Transaction.transaction_hash == tx_hash))
