from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models import Case
from .base import Repository

class CaseRepository(Repository[Case]):
    def __init__(self, db: Session):
        super().__init__(db, Case)
    def get_by_case_number(self, case_number: str):
        return self.db.scalar(select(Case).where(Case.case_number == case_number))
