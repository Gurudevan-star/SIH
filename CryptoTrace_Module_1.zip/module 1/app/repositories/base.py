from typing import Generic, TypeVar
from sqlalchemy import select
from sqlalchemy.orm import Session
T = TypeVar("T")

class Repository(Generic[T]):
    def __init__(self, db: Session, model: type[T]):
        self.db, self.model = db, model
    def get(self, obj_id):
        return self.db.get(self.model, obj_id)
    def list(self, limit=100, offset=0):
        return self.db.scalars(select(self.model).offset(offset).limit(limit)).all()
    def add(self, obj: T) -> T:
        self.db.add(obj)
        self.db.flush()
        return obj
