from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models import Wallet
from .base import Repository

class WalletRepository(Repository[Wallet]):
    def __init__(self, db: Session):
        super().__init__(db, Wallet)
    def get_by_network_address(self, network, address):
        return self.db.scalar(select(Wallet).where(Wallet.network == network, Wallet.address == address))
