# Module 4
## Blockchain Data Acquisition

This is the Module 4 stage of the cumulative CryptoTrace backend.
Later modules extend the same canonical persistence model.
