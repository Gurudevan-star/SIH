from pydantic import BaseModel, Field
from typing import List


class InvestigationCreate(BaseModel):

    case_id: str

    source_wallet: str

    chain: str = "ethereum"

    max_hops: int = Field(
        default=5,
        ge=1,
        le=20
    )

    min_transfer_value: float = Field(
        default=0,
        ge=0
    )

    time_window_days: int = Field(
        default=30,
        ge=1,
        le=3650
    )

    assets: List[str] = []
