from datetime import datetime, timezone
from typing import List, Dict


class MonitoringService:
    """
    Monitors wallets for newly observed blockchain transactions.
    """

    def __init__(self, blockchain_provider, risk_service, db):
        self.blockchain_provider = blockchain_provider
        self.risk_service = risk_service
        self.db = db

    async def check_wallet(self, wallet_address: str, chain: str):
        """
        Check wallet for new transactions.
        """

        transactions = await self.blockchain_provider.get_native_transactions(
            wallet_address=wallet_address,
            chain=chain
        )

        new_transactions = []

        for tx in transactions:

            # Replace with repository lookup
            already_exists = self.db.transaction_exists(
                tx_hash=tx["transaction_hash"]
            )

            if already_exists:
                continue

            self.db.save_transaction(tx)
            new_transactions.append(tx)

        alerts = []

        for tx in new_transactions:

            risk = self.risk_service.assess_transaction(tx)

            if risk["risk_score"] >= 70:

                alert = {
                    "wallet": wallet_address,
                    "transaction_hash": tx["transaction_hash"],
                    "alert_type": "NEW_HIGH_RISK_TRANSACTION",
                    "severity": "HIGH",
                    "risk_score": risk["risk_score"],
                    "created_at": datetime.now(timezone.utc).isoformat()
                }

                self.db.save_alert(alert)
                alerts.append(alert)

        return {
            "wallet": wallet_address,
            "new_transactions": new_transactions,
            "alerts": alerts
        }
