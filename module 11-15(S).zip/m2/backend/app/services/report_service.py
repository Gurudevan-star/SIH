from datetime import datetime, timezone
from typing import Dict, Any


class ReportService:

    def __init__(self, db):
        self.db = db

    def generate_report(self, investigation: Dict[str, Any]):

        report = {
            "report_id": f"RPT-{investigation['investigation']['id']}",
            "investigation_id": investigation["investigation"]["id"],
            "generated_at": datetime.now(
                timezone.utc
            ).isoformat(),

            "case": investigation.get("case"),

            "source_wallet":
                investigation.get("source_wallet"),

            "transaction_summary":
                investigation.get("transactions", []),

            "fund_flow":
                investigation.get("fund_flow", {}),

            "clusters":
                investigation.get("clusters", []),

            "exchange_matches":
                investigation.get("exchange_matches", []),

            "risk_assessment":
                investigation.get("risk_assessment", {}),

            "attribution":
                investigation.get("attribution", {}),

            "evidence":
                investigation.get("evidence", [])
        }

        self.db.save_report(report)

        return report


def generate_html_report(report: Dict[str, Any]) -> str:

    risk = report.get("risk_assessment", {})

    html = f"""
    <!DOCTYPE html>

    <html>

    <head>

        <title>CryptoTrace Investigation Report</title>

        <style>

            body {{
                font-family: Arial, sans-serif;
                margin: 40px;
            }}

            h1 {{
                border-bottom: 2px solid #222;
                padding-bottom: 10px;
            }}

            .section {{
                margin-top: 30px;
            }}

            .risk {{
                font-size: 28px;
                font-weight: bold;
            }}

            table {{
                border-collapse: collapse;
                width: 100%;
            }}

            th, td {{
                border: 1px solid #ddd;
                padding: 8px;
            }}

        </style>

    </head>

    <body>

        <h1>CryptoTrace Investigation Report</h1>

        <div class="section">

            <h2>Investigation</h2>

            <p>
                Investigation ID:
                {report["investigation_id"]}
            </p>

            <p>
                Generated:
                {report["generated_at"]}
            </p>

        </div>

        <div class="section">

            <h2>Source Wallet</h2>

            <p>
                {report.get("source_wallet")}
            </p>

        </div>

        <div class="section">

            <h2>Risk Assessment</h2>

            <p class="risk">
                Score:
                {risk.get("risk_score", 0)}/100
            </p>

            <p>
                Level:
                {risk.get("risk_level", "UNKNOWN")}
            </p>

        </div>

        <div class="section">

            <h2>Exchange Intelligence</h2>

            <pre>
{report.get("exchange_matches")}
            </pre>

        </div>

        <div class="section">

            <h2>Evidence</h2>

            <pre>
{report.get("evidence")}
            </pre>

        </div>

    </body>

    </html>
    """

    return html
