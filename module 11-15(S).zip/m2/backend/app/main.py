from fastapi import FastAPI

from app.routes.cases import router as case_router if False else None
from app.routes.investigations import router as investigation_router
from app.routes.monitoring import router as monitoring_router
from app.routes.websocket import router as websocket_router

app = FastAPI(
    title="CryptoTrace API",
    version="1.0.0",
    description="Blockchain Forensics and Investigation Platform"
)


@app.get("/health")
def health():

    return {
        "status": "healthy",
        "service": "cryptotrace"
    }


@app.get("/ready")
def ready():

    return {
        "status": "ready"
    }


app.include_router(
    investigation_router,
    prefix="/api/investigations",
    tags=["Investigations"]
)

app.include_router(
    monitoring_router,
    prefix="/api",
    tags=["Monitoring"]
)

app.include_router(
    websocket_router,
    tags=["WebSocket"]
)
