from typing import List, Dict, Any


class SimpleBlockchainProvider:

    async def get_native_transactions(self, wallet_address: str, chain: str) -> List[Dict[str, Any]]:
        # Demo stub: return empty list or sample transactions
        return []
