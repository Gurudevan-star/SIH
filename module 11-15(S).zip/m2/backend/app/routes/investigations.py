from fastapi import APIRouter, HTTPException
from uuid import uuid4

from app.schemas.investigation import InvestigationCreate
from app.repositories.in_memory import db

router = APIRouter()


@router.post("")
async def create_investigation(
    request: InvestigationCreate
):

    try:

        investigation_id = f"INV-{uuid4().hex[:8].upper()}"

        investigation = {
            "id": investigation_id,
            "case_id": request.case_id,
            "source_wallet": request.source_wallet,
            "chain": request.chain,
            "max_hops": request.max_hops,
            "min_transfer_value":
                request.min_transfer_value,
            "time_window_days":
                request.time_window_days,
            "assets": request.assets,
            "status": "CREATED"
        }

        # Save investigation using repository/service
        db.save_investigation(investigation)

        # Orchestrator could be started here in background

        return investigation

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=str(exc)
        )


@router.get("/{investigation_id}")
async def get_investigation(
    investigation_id: str
):

    investigation = db.get_investigation(
        investigation_id
    )

    if not investigation:

        raise HTTPException(
            status_code=404,
            detail="Investigation not found"
        )

    # augment with any saved result if present
    result = {"investigation": investigation}

    stored_result = db.results.get(investigation_id)
    if stored_result:
        result.update(stored_result)

    return result
