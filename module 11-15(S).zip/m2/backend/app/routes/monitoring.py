from fastapi import APIRouter, HTTPException
from app.repositories.in_memory import db
from app.providers.blockchain import SimpleBlockchainProvider
from app.services.risk_service import RiskService
from app.services.monitoring_service import MonitoringService

router = APIRouter()

# simple wiring for demo purposes
blockchain = SimpleBlockchainProvider()
risk_service = RiskService()
monitoring_service = MonitoringService(blockchain, risk_service, db)


@router.post("/monitor/check/{wallet_address}/{chain}")
async def check_wallet(wallet_address: str, chain: str):

    try:
        result = await monitoring_service.check_wallet(
            wallet_address=wallet_address,
            chain=chain
        )

        return result

    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))
