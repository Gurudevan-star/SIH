from typing import Dict, List, Any


class InMemoryDB:

    def __init__(self):
        self.investigations: Dict[str, Dict[str, Any]] = {}
        self.transactions: Dict[str, Dict[str, Any]] = {}
        self.alerts: List[Dict[str, Any]] = []
        self.reports: Dict[str, Dict[str, Any]] = {}
        self.results: Dict[str, Dict[str, Any]] = {}

    # Investigation repository methods
    def save_investigation(self, investigation: Dict[str, Any]):
        self.investigations[investigation["id"]] = investigation

    def get_investigation(self, investigation_id: str):
        return self.investigations.get(investigation_id)

    def update_status(self, investigation_id: str, status: str):
        if investigation_id in self.investigations:
            self.investigations[investigation_id]["status"] = status

    def save_error(self, investigation_id: str, error: str):
        if investigation_id in self.investigations:
            self.investigations[investigation_id]["error"] = error

    # Transaction repository methods
    def transaction_exists(self, tx_hash: str) -> bool:
        return tx_hash in self.transactions

    def save_transaction(self, tx: Dict[str, Any]):
        self.transactions[tx["transaction_hash"]] = tx

    def save_alert(self, alert: Dict[str, Any]):
        self.alerts.append(alert)

    def save_report(self, report: Dict[str, Any]):
        self.reports[report["report_id"]] = report

    def save_investigation_result(self, investigation_id: str, result: Dict[str, Any]):
        self.results[investigation_id] = result


# shared db instance for simple wiring
db = InMemoryDB()
