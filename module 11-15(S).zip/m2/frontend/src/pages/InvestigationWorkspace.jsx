import { useEffect, useState } from "react";
import { getInvestigation } from "../api/cryptotrace";

export default function InvestigationWorkspace({
  investigationId
}) {

  const [data, setData] = useState(null);

  useEffect(() => {

    loadInvestigation();

    const interval =
      setInterval(
        loadInvestigation,
        3000
      );

    return () =>
      clearInterval(interval);

  }, [investigationId]);

  async function loadInvestigation() {

    try {

      const result =
        await getInvestigation(
          investigationId
        );

      setData(result);

    } catch (error) {

      console.error(error);

    }
  }

  if (!data) {

    return (
      <div>
        Loading investigation...
      </div>
    );

  }

  return (

    <div className="workspace">

      <header>

        <h1>
          CryptoTrace Investigation
        </h1>

        <p>
          Investigation ID:
          {data.investigation?.id}
        </p>

      </header>

      <section>

        <h2>
          Investigation Status
        </h2>

        <strong>
          {data.investigation?.status}
        </strong>

      </section>

      <section>

        <h2>
          Subject Wallet
        </h2>

        <code>
          {data.source_wallet}
        </code>

      </section>

      <section>

        <h2>
          Risk Assessment
        </h2>

        <h3>
          {data.risk_assessment?.risk_score}
          /100
        </h3>

        <p>
          {data.risk_assessment?.risk_level}
        </p>

      </section>

      <section>

        <h2>
          Transactions
        </h2>

        <p>
          {data.transactions?.length || 0}
          transactions
        </p>

      </section>

      <section>

        <h2>
          Exchange Intelligence
        </h2>

        <p>
          {data.exchange_matches?.length || 0}
          matches
        </p>

      </section>

    </div>

  );
}
