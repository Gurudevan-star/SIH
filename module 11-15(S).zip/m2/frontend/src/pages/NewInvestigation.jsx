import { useState } from "react";
import { createInvestigation } from "../api/cryptotrace";

export default function NewInvestigation() {

  const [wallet, setWallet] = useState("");
  const [chain, setChain] = useState("ethereum");
  const [hops, setHops] = useState(5);
  const [loading, setLoading] = useState(false);

  async function startInvestigation() {

    if (!wallet.trim()) {
      alert("Enter a wallet address");
      return;
    }

    setLoading(true);

    try {

      const result =
        await createInvestigation({

          case_id: "CASE-001",

          source_wallet: wallet,

          chain: chain,

          max_hops: Number(hops),

          min_transfer_value: 0,

          time_window_days: 30,

          assets: []

        });

      window.location.href =
        `/investigation/${result.id}`;

    } catch (error) {

      alert(error.message);

    } finally {

      setLoading(false);

    }
  }

  return (

    <div className="investigation-form">

      <h1>Start Investigation</h1>

      <label>
        Subject Wallet
      </label>

      <input
        value={wallet}
        onChange={
          e => setWallet(e.target.value)
        }
        placeholder="0x..."
      />

      <label>
        Blockchain
      </label>

      <select
        value={chain}
        onChange={
          e => setChain(e.target.value)
        }
      >

        <option value="ethereum">
          Ethereum
        </option>

        <option value="polygon">
          Polygon
        </option>

        <option value="bsc">
          BNB Smart Chain
        </option>

      </select>

      <label>
        Maximum Hops
      </label>

      <input
        type="number"
        min="1"
        max="20"
        value={hops}
        onChange={
          e => setHops(e.target.value)
        }
      />

      <button
        onClick={startInvestigation}
        disabled={loading}
      >

        {loading
          ? "Starting..."
          : "Start Investigation"}

      </button>

    </div>

  );
}
