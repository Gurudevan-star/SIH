const API_URL =
  import.meta?.env?.VITE_API_URL ||
  "http://localhost:8000";

export async function createInvestigation(data) {

  const response = await fetch(
    `${API_URL}/api/investigations`,
    {
      method: "POST",

      headers: {
        "Content-Type": "application/json"
      },

      body: JSON.stringify(data)
    }
  );

  if (!response.ok) {
    throw new Error(
      "Failed to create investigation"
    );
  }

  return response.json();
}

export async function getInvestigation(id) {

  const response = await fetch(
    `${API_URL}/api/investigations/${id}`
  );

  if (!response.ok) {
    throw new Error(
      "Investigation not found"
    );
  }

  return response.json();
}
