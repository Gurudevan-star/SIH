import { useEffect, useState } from "react";

export function useInvestigationSocket(
  investigationId
) {

  const [alerts, setAlerts] = useState([]);

  useEffect(() => {

    const socket =
      new WebSocket(
        `ws://localhost:8000/ws/investigations/${investigationId}`
      );

    socket.onopen = () => {

      console.log(
        "CryptoTrace WebSocket connected"
      );

      socket.send("subscribe");

    };

    socket.onmessage = event => {

      const message =
        JSON.parse(event.data);

      setAlerts(
        previous => [
          message,
          ...previous
        ]
      );

    };

    socket.onerror = error => {

      console.error(
        "WebSocket error",
        error
      );

    };

    socket.onclose = () => {

      console.log(
        "WebSocket disconnected"
      );

    };

    return () => {

      socket.close();

    };

  }, [investigationId]);

  return alerts;
}
