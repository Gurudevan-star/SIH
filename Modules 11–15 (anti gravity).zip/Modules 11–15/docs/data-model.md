# Data Model Specification

To eliminate floating-point precision loss in financial transactions, all cryptocurrency values across schemas and models use `Decimal`.

## Investigation Entity
```json
{
  "id": "INV-001",
  "case_id": "CASE-001",
  "source_wallet": "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
  "chain": "ethereum",
  "max_hops": 5,
  "min_transfer_value": "0.0",
  "time_window_days": 30,
  "assets": ["ETH", "USDT"],
  "status": "COMPLETED"
}
```

## Transaction Schema (`Decimal` Amounts)
```json
{
  "transaction_hash": "0x8f3c7b2a...",
  "sender": "0x71C7656...",
  "receiver": "0x28C6c06...",
  "amount": "145.500000000000000000",
  "asset": "ETH"
}
```
