# CryptoTrace System Architecture

CryptoTrace is structured as a decoupled, service-oriented architecture designed to scale seamlessly.

```
       +-------------------------------------------------------+
       |                 React Investigator UI                 |
       |     (Dashboard / Workspace / Live Alerts / Report)    |
       +---------------------------+---------------------------+
                                   | HTTP REST & WebSockets
                                   v
       +-------------------------------------------------------+
       |                  FastAPI API Gateway                  |
       |  /api/cases | /api/investigations | /api/monitoring   |
       +---------------------------+---------------------------+
                                   |
                                   v
       +-------------------------------------------------------+
       |              Investigation Orchestrator               |
       +-----+-------+--------+--------+--------+-------+------+
             |       |        |        |        |       |
             v       v        v        v        v       v
           Wallet   Acq    Norm    Graph   Cluster Exchange Risk Evidence Report
           Service Serv    Serv    Serv     Serv     Serv   Serv   Serv   Serv
             |       |                                  |
             v       v                                  v
       +---------------------+                +---------------------+
       | Blockchain Provider |                | Exchange Provider   |
       +---------------------+                +---------------------+
```

## Key Components

1. **Investigation Orchestrator**: Executes 10 discrete workflow phases, updating state transitions in the repository layer and broadcasting real-time progress via WebSocket (`ConnectionManager`).
2. **Real-Time Monitoring Service**: Periodically audits registered wallets for new on-chain activity, assesses transaction risk, saves alerts, and notifies active WebSockets.
3. **Automated HTML Report Generator**: Converts investigation results into a clean, court-ready HTML report structure with risk badges, fund flow summaries, and forensic evidence logs.
