# Blockchain Provider Interface

The `BlockchainProvider` abstracts interaction with node providers (Infura, Alchemy, Etherscan, Ankr, or internal indexers).

```python
class BlockchainProvider:
    async def get_native_transactions(self, wallet_address: str, chain: str) -> list[dict]:
        """Fetch native currency transfers for target address."""
        ...

    async def get_token_transfers(self, wallet_address: str, chain: str) -> list[dict]:
        """Fetch ERC20/SPL/BEP20 token transfers for target address."""
        ...
```
