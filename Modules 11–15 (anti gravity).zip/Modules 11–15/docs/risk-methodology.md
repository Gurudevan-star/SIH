# Risk Scoring Methodology

CryptoTrace evaluates risk using a composite score ranging from 0 to 100:

$$ \text{Risk Score} = \min\left(100, \sum w_i \cdot S_i\right) $$

| Indicator | Weight ($w_i$) | Score Range ($S_i$) | Description |
|-----------|---------------+--------------------+-------------|
| Sanctioned Entity Direct Exposure | 0.50 | 100 | Wallet directly sent/received funds from OFAC/Lazarus entity |
| Privacy Mixer Interaction | 0.30 | 90 | Transactions involving Tornado Cash or coinjoin |
| Rapid Peeling Chain Movement | 0.10 | 75 | Fast sequential splits of funds |
| High-Value Anomaly | 0.10 | 60 | Transfer values exceeding 95th percentile |

## Risk Levels
- **0 - 29**: LOW
- **30 - 59**: MEDIUM
- **60 - 79**: HIGH
- **80 - 100**: CRITICAL
