from fastapi import WebSocket


class ConnectionManager:

    def __init__(self):
        self.active_connections = {}

    async def connect(self, investigation_id: str, websocket: WebSocket):

        await websocket.accept()

        if investigation_id not in self.active_connections:
            self.active_connections[investigation_id] = []

        self.active_connections[investigation_id].append(websocket)

    def disconnect(self, investigation_id: str, websocket: WebSocket):

        if investigation_id in self.active_connections:

            if websocket in self.active_connections[investigation_id]:
                self.active_connections[investigation_id].remove(websocket)

    async def broadcast(self, investigation_id: str, message: dict):

        connections = self.active_connections.get(
            investigation_id,
            []
        )

        for websocket in list(connections):
            try:
                await websocket.send_json(message)
            except Exception as e:
                print(f"[WebSocket ConnectionManager] Error sending message: {e}")
