class AcquisitionService:
    """
    Acquires raw transaction activity from blockchain providers.
    """

    def __init__(self, blockchain_provider):
        self.blockchain_provider = blockchain_provider

    async def fetch_wallet_activity(self, wallet_address: str, chain: str = "ethereum") -> list[dict]:
        native_txs = await self.blockchain_provider.get_native_transactions(
            wallet_address=wallet_address,
            chain=chain
        )
        return native_txs
