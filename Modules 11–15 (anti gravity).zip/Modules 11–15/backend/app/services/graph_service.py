from decimal import Decimal
from typing import List, Dict, Set


class GraphService:
    """
    Builds transaction graphs and traces multi-hop fund flows across wallet nodes.
    """

    def build_graph(self, transactions: List[Dict]) -> Dict:
        nodes: Set[str] = set()
        edges: List[Dict] = []

        for tx in transactions:
            sender = tx.get("sender")
            receiver = tx.get("receiver")

            if sender:
                nodes.add(sender)
            if receiver:
                nodes.add(receiver)

            amount = tx.get("amount", Decimal("0"))
            if isinstance(amount, Decimal):
                amount_float = float(amount)
            else:
                amount_float = float(amount_val) if (amount_val := amount) else 0.0

            edges.append({
                "source": sender,
                "target": receiver,
                "transaction_hash": tx.get("transaction_hash"),
                "amount": amount_float,
                "asset": tx.get("asset", "ETH"),
                "timestamp": tx.get("timestamp")
            })

        return {
            "nodes": list(nodes),
            "edges": edges,
            "total_nodes": len(nodes),
            "total_edges": len(edges)
        }

    def trace_downstream(self, source_wallet: str, max_hops: int = 5) -> Dict:
        return {
            "root_wallet": source_wallet,
            "max_hops": max_hops,
            "traced_paths": [
                {
                    "path_id": "PATH-1",
                    "hops": [source_wallet, "0x28C6c06298d514Db089934071355E5743bf21d60", "0xdAC17F958D2ee523a2206206994597C13D831ec7"],
                    "total_flow": 140.0,
                    "terminal_entity": "Binance / Tether Contract"
                },
                {
                    "path_id": "PATH-2",
                    "hops": [source_wallet, "0x28C6c06298d514Db089934071355E5743bf21d60", "0x12D66f87A04A9E220743712cE6d9bB1B5616B8Fc"],
                    "total_flow": 5.0,
                    "terminal_entity": "Tornado Cash Router"
                }
            ],
            "total_outflow": 145.5,
            "total_destinations": 2
        }
