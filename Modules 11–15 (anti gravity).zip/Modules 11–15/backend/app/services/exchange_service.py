class ExchangeService:
    """
    Matches wallet addresses against known VASPs and exchange intelligence data.
    """

    def __init__(self, exchange_provider):
        self.exchange_provider = exchange_provider

    def match_address(self, address: str, chain: str = "ethereum") -> dict | None:
        match_info = self.exchange_provider.lookup_address(address)
        if match_info:
            return {
                "address": address,
                "chain": chain,
                "entity_name": match_info.get("name"),
                "category": match_info.get("category"),
                "risk_level": match_info.get("risk_level"),
                "sanctioned": match_info.get("sanctioned", False),
                "confidence": match_info.get("confidence", 0.9)
            }
        return None
