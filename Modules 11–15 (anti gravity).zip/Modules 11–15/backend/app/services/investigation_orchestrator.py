class InvestigationOrchestrator:

    def __init__(
        self,
        wallet_service,
        acquisition_service,
        normalization_service,
        graph_service,
        clustering_service,
        exchange_service,
        risk_service,
        evidence_service,
        report_service,
        db,
        websocket_manager=None
    ):

        self.wallet_service = wallet_service
        self.acquisition_service = acquisition_service
        self.normalization_service = normalization_service
        self.graph_service = graph_service
        self.clustering_service = clustering_service
        self.exchange_service = exchange_service
        self.risk_service = risk_service
        self.evidence_service = evidence_service
        self.report_service = report_service
        self.db = db
        self.websocket_manager = websocket_manager

    async def _notify_progress(self, investigation_id: str, status: str):
        self.db.update_status(investigation_id, status)
        if self.websocket_manager:
            try:
                await self.websocket_manager.broadcast(
                    investigation_id,
                    {
                        "type": "STATUS_UPDATE",
                        "investigation_id": investigation_id,
                        "status": status
                    }
                )
            except Exception as e:
                print(f"[Orchestrator] WS broadcast warning: {e}")

    async def run(self, investigation):

        investigation_id = investigation["id"]

        try:

            # --------------------------------
            # 1. VALIDATION
            # --------------------------------

            await self._notify_progress(
                investigation_id,
                "VALIDATING"
            )

            wallet = await self.wallet_service.validate(
                investigation["source_wallet"],
                investigation.get("chain", "ethereum")
            )

            if not wallet["address_valid"]:
                raise ValueError("Invalid wallet address")

            # --------------------------------
            # 2. DATA ACQUISITION
            # --------------------------------

            await self._notify_progress(
                investigation_id,
                "FETCHING_DATA"
            )

            raw_transactions = await (
                self.acquisition_service.fetch_wallet_activity(
                    investigation["source_wallet"],
                    investigation.get("chain", "ethereum")
                )
            )

            # --------------------------------
            # 3. NORMALIZATION
            # --------------------------------

            await self._notify_progress(
                investigation_id,
                "NORMALIZING"
            )

            transactions = (
                self.normalization_service.normalize(
                    raw_transactions
                )
            )

            # --------------------------------
            # 4. GRAPH
            # --------------------------------

            await self._notify_progress(
                investigation_id,
                "TRACING"
            )

            graph = self.graph_service.build_graph(
                transactions
            )

            fund_flow = self.graph_service.trace_downstream(
                investigation["source_wallet"],
                investigation.get("max_hops", 5)
            )

            # --------------------------------
            # 5. CLUSTERING
            # --------------------------------

            await self._notify_progress(
                investigation_id,
                "CLUSTERING"
            )

            clusters = self.clustering_service.cluster(
                graph
            )

            # --------------------------------
            # 6. EXCHANGE INTELLIGENCE
            # --------------------------------

            await self._notify_progress(
                investigation_id,
                "MATCHING"
            )

            exchange_matches = []

            for node in graph["nodes"]:

                match = (
                    self.exchange_service.match_address(
                        node,
                        investigation.get("chain", "ethereum")
                    )
                )

                if match:
                    exchange_matches.append(match)

            # --------------------------------
            # 7. RISK
            # --------------------------------

            await self._notify_progress(
                investigation_id,
                "SCORING"
            )

            risk = self.risk_service.assess(
                transactions=transactions,
                graph=graph,
                clusters=clusters,
                exchange_matches=exchange_matches
            )

            # --------------------------------
            # 8. EVIDENCE
            # --------------------------------

            evidence = (
                self.evidence_service
                .build_investigation_evidence(
                    investigation_id
                )
            )

            # --------------------------------
            # 9. RESULT
            # --------------------------------

            result = {

                "case": investigation.get("case"),

                "investigation": investigation,

                "source_wallet":
                    investigation["source_wallet"],

                "transactions":
                    transactions,

                "fund_flow":
                    fund_flow,

                "clusters":
                    clusters,

                "exchange_matches":
                    exchange_matches,

                "risk_assessment":
                    risk,

                "attribution":
                    risk.get("attribution", {}),

                "evidence":
                    evidence
            }

            # --------------------------------
            # 10. REPORT
            # --------------------------------

            report = self.report_service.generate_report(
                result
            )

            result["report"] = report

            self.db.save_investigation_result(
                investigation_id,
                result
            )

            await self._notify_progress(
                investigation_id,
                "COMPLETED"
            )

            return result

        except Exception as exc:

            self.db.update_status(
                investigation_id,
                "FAILED"
            )

            self.db.save_error(
                investigation_id,
                str(exc)
            )

            raise
