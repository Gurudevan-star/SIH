from decimal import Decimal
from typing import List, Dict


class NormalizationService:
    """
    Normalizes raw transactions to standard schema using Decimal for amounts.
    """

    def normalize(self, raw_transactions: List[Dict]) -> List[Dict]:
        normalized = []

        for tx in raw_transactions:
            amount_val = tx.get("amount", 0)
            if not isinstance(amount_val, Decimal):
                amount_val = Decimal(str(amount_val))

            norm_tx = {
                "transaction_hash": tx.get("transaction_hash") or tx.get("hash"),
                "chain": tx.get("chain", "ethereum").lower(),
                "block_number": int(tx.get("block_number", 0)),
                "timestamp": tx.get("timestamp"),
                "sender": tx.get("sender") or tx.get("from"),
                "receiver": tx.get("receiver") or tx.get("to"),
                "amount": amount_val,
                "asset": tx.get("asset", "ETH"),
                "fee": Decimal(str(tx.get("fee", "0.001"))),
                "status": tx.get("status", "CONFIRMED")
            }
            normalized.append(norm_tx)

        return normalized
