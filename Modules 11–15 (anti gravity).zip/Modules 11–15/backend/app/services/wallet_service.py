import re


class WalletService:
    """
    Validates wallet syntax, address formats, and chain support.
    """

    async def validate(self, wallet_address: str, chain: str = "ethereum") -> dict:
        wallet_address = wallet_address.strip()
        chain = chain.lower()

        # EVM chains check (0x followed by 40 hex chars)
        if chain in ["ethereum", "polygon", "bsc", "arbitrum", "optimism"]:
            is_valid = bool(re.match(r"^0x[a-fA-F0-9]{40}$", wallet_address))
            return {
                "address": wallet_address,
                "chain": chain,
                "address_valid": is_valid,
                "format": "EVM_CHECKSUMMED" if is_valid else "INVALID"
            }
        
        # Generic check fallback
        is_valid = len(wallet_address) >= 26 and len(wallet_address) <= 64
        return {
            "address": wallet_address,
            "chain": chain,
            "address_valid": is_valid,
            "format": "GENERIC" if is_valid else "INVALID"
        }
