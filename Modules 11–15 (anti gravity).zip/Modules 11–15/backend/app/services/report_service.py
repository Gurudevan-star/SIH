from datetime import datetime, timezone


class ReportService:

    def __init__(self, db):
        self.db = db

    def generate_report(self, investigation):

        # Access id properly whether investigation dict is flat or nested
        inv_data = investigation.get("investigation", investigation)
        inv_id = inv_data.get("id", "INV-UNKNOWN") if isinstance(inv_data, dict) else "INV-UNKNOWN"

        report = {
            "report_id": f"RPT-{inv_id}",
            "investigation_id": inv_id,
            "generated_at": datetime.now(
                timezone.utc
            ).isoformat(),

            "case": investigation.get("case"),

            "source_wallet":
                investigation.get("source_wallet"),

            "transaction_summary":
                investigation.get("transactions", []),

            "fund_flow":
                investigation.get("fund_flow", {}),

            "clusters":
                investigation.get("clusters", []),

            "exchange_matches":
                investigation.get("exchange_matches", []),

            "risk_assessment":
                investigation.get("risk_assessment", {}),

            "attribution":
                investigation.get("attribution", {}),

            "evidence":
                investigation.get("evidence", [])
        }

        self.db.save_report(report)

        return report


def generate_html_report(report):

    risk = report.get("risk_assessment", {})
    risk_level = risk.get("risk_level", "UNKNOWN")
    risk_score = risk.get("risk_score", 0)

    badge_color = "#10b981"  # green
    if risk_level in ["CRITICAL", "HIGH"]:
        badge_color = "#ef4444"  # red
    elif risk_level == "MEDIUM":
        badge_color = "#f59e0b"  # amber

    exchange_matches_str = str(report.get("exchange_matches", []))
    evidence_str = str(report.get("evidence", []))

    html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>CryptoTrace Investigation Report - {report["report_id"]}</title>
    <style>
        body {{
            font-family: 'Segoe UI', Arial, sans-serif;
            margin: 40px;
            background-color: #f8fafc;
            color: #0f172a;
        }}
        .container {{
            max-width: 900px;
            margin: 0 auto;
            background: #ffffff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            border: 1px solid #e2e8f0;
        }}
        h1 {{
            border-bottom: 3px solid #0f172a;
            padding-bottom: 12px;
            color: #0f172a;
            font-size: 28px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}
        .section {{
            margin-top: 30px;
            padding-top: 15px;
            border-top: 1px solid #e2e8f0;
        }}
        h2 {{
            color: #1e293b;
            font-size: 18px;
            margin-bottom: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }}
        .risk {{
            font-size: 32px;
            font-weight: bold;
            color: {badge_color};
            margin: 10px 0;
        }}
        .risk-badge {{
            display: inline-block;
            padding: 4px 12px;
            border-radius: 4px;
            color: white;
            background: {badge_color};
            font-weight: bold;
            font-size: 14px;
        }}
        table {{
            border-collapse: collapse;
            width: 100%;
            margin-top: 10px;
        }}
        th, td {{
            border: 1px solid #cbd5e1;
            padding: 10px;
            text-align: left;
            font-size: 14px;
        }}
        th {{
            background-color: #f1f5f9;
            font-weight: 600;
        }}
        pre {{
            background: #0f172a;
            color: #38bdf8;
            padding: 16px;
            border-radius: 6px;
            overflow-x: auto;
            font-size: 13px;
        }}
        .meta-grid {{
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }}
        .meta-card {{
            background: #f8fafc;
            padding: 16px;
            border-radius: 6px;
            border: 1px solid #e2e8f0;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>
            <span>CryptoTrace Forensic Report</span>
            <span style="font-size: 14px; color: #64748b;">{report["report_id"]}</span>
        </h1>

        <div class="meta-grid">
            <div class="meta-card">
                <h2>Investigation Metadata</h2>
                <p><strong>Investigation ID:</strong> {report["investigation_id"]}</p>
                <p><strong>Generated:</strong> {report["generated_at"]}</p>
            </div>
            <div class="meta-card">
                <h2>Subject Wallet</h2>
                <p><code>{report["source_wallet"]}</code></p>
            </div>
        </div>

        <div class="section">
            <h2>Risk Assessment</h2>
            <div class="risk">
                Score: {risk_score}/100
                <span class="risk-badge">{risk_level}</span>
            </div>
        </div>

        <div class="section">
            <h2>Exchange Intelligence Matches</h2>
            <pre>{exchange_matches_str}</pre>
        </div>

        <div class="section">
            <h2>Forensic Evidence Audit Trail</h2>
            <pre>{evidence_str}</pre>
        </div>
    </div>
</body>
</html>
"""

    return html
