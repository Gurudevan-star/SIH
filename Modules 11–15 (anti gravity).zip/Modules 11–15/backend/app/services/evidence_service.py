from datetime import datetime, timezone
import hashlib


class EvidenceService:
    """
    Builds forensic evidence logs and cryptographic hashes for chain of custody.
    """

    def build_investigation_evidence(self, investigation_id: str) -> list[dict]:
        timestamp = datetime.now(timezone.utc).isoformat()
        
        raw_payload = f"INVESTIGATION-{investigation_id}-{timestamp}"
        merkle_root = hashlib.sha256(raw_payload.encode()).hexdigest()

        return [
            {
                "evidence_id": f"EVD-{investigation_id}-01",
                "type": "ON_CHAIN_TRANSACTION_RECORD",
                "description": "Native Ethereum transaction log retrieved from block indexer",
                "timestamp": timestamp,
                "verification_hash": merkle_root,
                "chain_of_custody_verified": True
            },
            {
                "evidence_id": f"EVD-{investigation_id}-02",
                "type": "VASP_MATCH_RECORD",
                "description": "Matched node 0x28C6c06298d514Db089934071355E5743bf21d60 to Binance Hot Wallet 14",
                "timestamp": timestamp,
                "verification_hash": hashlib.sha256((merkle_root + "vasp").encode()).hexdigest(),
                "chain_of_custody_verified": True
            }
        ]
