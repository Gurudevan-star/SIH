from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.routes.cases import router as case_router
from app.routes.investigations import router as investigation_router
from app.routes.monitoring import router as monitoring_router
from app.routes.websocket import router as websocket_router

app = FastAPI(
    title="CryptoTrace API",
    version="1.0.0",
    description="Blockchain Forensics and Investigation Platform"
)

# Enable CORS for frontend interface
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health():

    return {
        "status": "healthy",
        "service": "cryptotrace"
    }


@app.get("/ready")
def ready():

    return {
        "status": "ready"
    }


app.include_router(
    case_router,
    prefix="/api/cases",
    tags=["Cases"]
)

app.include_router(
    investigation_router,
    prefix="/api/investigations",
    tags=["Investigations"]
)

app.include_router(
    monitoring_router,
    prefix="/api",
    tags=["Monitoring"]
)

app.include_router(
    websocket_router,
    tags=["WebSocket"]
)
