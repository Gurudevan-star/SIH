import json
import os
from typing import Dict, Optional


class ExchangeProvider:
    """
    Exchange provider to match on-chain wallet nodes against known VASPs,
    exchanges, mixers, and sanctioned intelligence entities.
    """

    def __init__(self, data_dir: str = None):
        if data_dir is None:
            base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            data_dir = os.path.join(os.path.dirname(base_dir), "data")
        self.data_dir = data_dir
        self.directory: Dict[str, dict] = {}
        self._load_directory()

    def _load_directory(self):
        file_path = os.path.join(self.data_dir, "exchange_intelligence.json")
        if os.path.exists(file_path):
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    entries = json.load(f)
                    for entry in entries:
                        self.directory[entry["address"].lower()] = entry
            except Exception as e:
                print(f"[ExchangeProvider] Warning loading exchange intelligence: {e}")

    def lookup_address(self, address: str) -> Optional[dict]:
        return self.directory.get(address.lower())
