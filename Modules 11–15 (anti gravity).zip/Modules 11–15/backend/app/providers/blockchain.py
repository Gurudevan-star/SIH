import json
import os
from decimal import Decimal
from typing import List, Dict


class BlockchainProvider:
    """
    Blockchain provider fetching native transactions and token transfers
    from on-chain indexer or synthetic intelligence store.
    """

    def __init__(self, data_dir: str = None):
        if data_dir is None:
            base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            data_dir = os.path.join(os.path.dirname(base_dir), "data")
        self.data_dir = data_dir

    async def get_native_transactions(self, wallet_address: str, chain: str = "ethereum") -> List[Dict]:
        tx_file = os.path.join(self.data_dir, "demo_transactions.json")
        w_lower = wallet_address.lower()
        matched = []

        if os.path.exists(tx_file):
            try:
                with open(tx_file, "r", encoding="utf-8") as f:
                    all_txs = json.load(f)
                    for tx in all_txs:
                        sender = tx.get("sender", "").lower()
                        receiver = tx.get("receiver", "").lower()
                        tx_chain = tx.get("chain", "ethereum").lower()

                        if (sender == w_lower or receiver == w_lower) and tx_chain == chain.lower():
                            tx_copy = dict(tx)
                            if isinstance(tx_copy.get("amount"), str):
                                tx_copy["amount"] = Decimal(tx_copy["amount"])
                            matched.append(tx_copy)
            except Exception as e:
                print(f"[BlockchainProvider] Error reading tx file: {e}")

        # If synthetic matching yields empty, generate synthetic activity graph for demonstration
        if not matched:
            matched = [
                {
                    "transaction_hash": f"0x{hash(wallet_address + '1'):x}".zfill(64),
                    "chain": chain,
                    "block_number": 19284000,
                    "timestamp": "2026-09-01T12:00:00Z",
                    "sender": wallet_address,
                    "receiver": "0x28C6c06298d514Db089934071355E5743bf21d60",
                    "amount": Decimal("10.50"),
                    "asset": "ETH" if chain == "ethereum" else "MATIC",
                    "status": "CONFIRMED"
                },
                {
                    "transaction_hash": f"0x{hash(wallet_address + '2'):x}".zfill(64),
                    "chain": chain,
                    "block_number": 19284050,
                    "timestamp": "2026-09-01T12:30:00Z",
                    "sender": "0x28C6c06298d514Db089934071355E5743bf21d60",
                    "receiver": "0x12D66f87A04A9E220743712cE6d9bB1B5616B8Fc",
                    "amount": Decimal("10.45"),
                    "asset": "ETH" if chain == "ethereum" else "MATIC",
                    "status": "CONFIRMED"
                }
            ]

        return matched
