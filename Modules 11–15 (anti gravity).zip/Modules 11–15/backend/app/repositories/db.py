import json
import os

from datetime import datetime, timezone
from decimal import Decimal
from typing import Dict, List, Optional


class DatabaseRepository:
    """
    In-memory and JSON-persisted repository handling cases, investigations,
    transactions, alerts, evidence, and generated reports.
    """

    def __init__(self, data_dir: Optional[str] = None):
        if data_dir is None:
            base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            data_dir = os.path.join(os.path.dirname(base_dir), "data")

        self.data_dir = data_dir
        self.transactions: Dict[str, dict] = {}
        self.investigations: Dict[str, dict] = {}
        self.alerts: List[dict] = []
        self.reports: Dict[str, dict] = {}
        self.cases: Dict[str, dict] = {}

        self._seed_default_data()

    def _seed_default_data(self):
        # Create default case
        self.cases["CASE-001"] = {
            "id": "CASE-001",
            "title": "Operation Dark Money",
            "description": "Cross-chain laundering investigation into ransomware payout",
            "status": "OPEN",
            "created_at": datetime.now(timezone.utc).isoformat()
        }

        # Seed synthetic demo transactions if file exists
        tx_file = os.path.join(self.data_dir, "demo_transactions.json")
        if os.path.exists(tx_file):
            try:
                with open(tx_file, "r", encoding="utf-8") as f:
                    raw_txs = json.load(f)
                    for tx in raw_txs:
                        if isinstance(tx.get("amount"), str):
                            tx["amount"] = Decimal(tx["amount"])
                        self.transactions[tx["transaction_hash"]] = tx
            except Exception as e:
                print(f"[DB Repository] Warning seeding transactions: {e}")

    # --- Transaction Repository ---
    def transaction_exists(self, tx_hash: str) -> bool:
        return tx_hash in self.transactions

    def save_transaction(self, tx: dict):
        if "amount" in tx and not isinstance(tx["amount"], Decimal):
            tx["amount"] = Decimal(str(tx["amount"]))
        self.transactions[tx["transaction_hash"]] = tx

    def get_transactions_for_wallet(self, wallet_address: str) -> List[dict]:
        w_lower = wallet_address.lower()
        return [
            tx for tx in self.transactions.values()
            if tx.get("sender", "").lower() == w_lower or tx.get("receiver", "").lower() == w_lower
        ]

    # --- Alert Repository ---
    def save_alert(self, alert: dict):
        self.alerts.append(alert)

    def get_alerts(self, wallet: Optional[str] = None) -> List[dict]:
        if wallet:
            w_lower = wallet.lower()
            return [a for a in self.alerts if a.get("wallet", "").lower() == w_lower]
        return list(reversed(self.alerts))

    # --- Investigation Repository ---
    def save_investigation(self, investigation: dict):
        inv_id = investigation["id"]
        if inv_id not in self.investigations:
            self.investigations[inv_id] = {
                "id": inv_id,
                "case_id": investigation.get("case_id", "CASE-001"),
                "source_wallet": investigation.get("source_wallet"),
                "chain": investigation.get("chain", "ethereum"),
                "max_hops": investigation.get("max_hops", 5),
                "min_transfer_value": Decimal(str(investigation.get("min_transfer_value", 0))),
                "time_window_days": investigation.get("time_window_days", 30),
                "assets": investigation.get("assets", []),
                "status": investigation.get("status", "CREATED"),
                "created_at": datetime.now(timezone.utc).isoformat(),
                "result": None,
                "error": None
            }
        else:
            self.investigations[inv_id].update(investigation)

    def update_status(self, investigation_id: str, status: str):
        if investigation_id in self.investigations:
            self.investigations[investigation_id]["status"] = status
        else:
            self.investigations[investigation_id] = {
                "id": investigation_id,
                "status": status,
                "created_at": datetime.now(timezone.utc).isoformat()
            }

    def save_investigation_result(self, investigation_id: str, result: dict):
        if investigation_id in self.investigations:
            self.investigations[investigation_id]["result"] = result
            self.investigations[investigation_id]["status"] = "COMPLETED"

    def save_error(self, investigation_id: str, error_msg: str):
        if investigation_id in self.investigations:
            self.investigations[investigation_id]["error"] = error_msg
            self.investigations[investigation_id]["status"] = "FAILED"

    def get_investigation(self, investigation_id: str) -> Optional[dict]:
        inv = self.investigations.get(investigation_id)
        if not inv:
            return None
        # Format response structure expected by orchestrator / frontend
        if inv.get("result"):
            res = inv["result"]
            res["investigation"] = {
                "id": inv["id"],
                "case_id": inv.get("case_id"),
                "status": inv.get("status"),
                "chain": inv.get("chain"),
                "created_at": inv.get("created_at")
            }
            return res
        return {
            "investigation": inv,
            "source_wallet": inv.get("source_wallet"),
            "status": inv.get("status"),
            "transactions": [],
            "exchange_matches": [],
            "risk_assessment": {"risk_score": 0, "risk_level": "PENDING"}
        }

    def list_investigations(self) -> List[dict]:
        return list(self.investigations.values())

    # --- Report Repository ---
    def save_report(self, report: dict):
        self.reports[report["report_id"]] = report

    def get_report(self, report_id: str) -> Optional[dict]:
        return self.reports.get(report_id)

    # --- Case Repository ---
    def get_cases(self) -> List[dict]:
        return list(self.cases.values())

    def save_case(self, case: dict):
        self.cases[case["id"]] = case


# Global database instance
db = DatabaseRepository()
