import asyncio
import uuid
from fastapi import APIRouter, HTTPException, BackgroundTasks
from fastapi.responses import HTMLResponse

from app.schemas.investigation import InvestigationCreate
from app.repositories.db import db
from app.providers.blockchain import BlockchainProvider
from app.providers.exchange import ExchangeProvider
from app.services.wallet_service import WalletService
from app.services.acquisition_service import AcquisitionService
from app.services.normalization_service import NormalizationService
from app.services.graph_service import GraphService
from app.services.clustering_service import ClusteringService
from app.services.exchange_service import ExchangeService
from app.services.risk_service import RiskService
from app.services.evidence_service import EvidenceService
from app.services.report_service import ReportService, generate_html_report
from app.services.investigation_orchestrator import InvestigationOrchestrator
from app.routes.websocket import manager as ws_manager

router = APIRouter()

# Instantiate service pipeline
blockchain_provider = BlockchainProvider()
exchange_provider = ExchangeProvider()

wallet_service = WalletService()
acquisition_service = AcquisitionService(blockchain_provider)
normalization_service = NormalizationService()
graph_service = GraphService()
clustering_service = ClusteringService()
exchange_service = ExchangeService(exchange_provider)
risk_service = RiskService()
evidence_service = EvidenceService()
report_service = ReportService(db)

orchestrator = InvestigationOrchestrator(
    wallet_service=wallet_service,
    acquisition_service=acquisition_service,
    normalization_service=normalization_service,
    graph_service=graph_service,
    clustering_service=clustering_service,
    exchange_service=exchange_service,
    risk_service=risk_service,
    evidence_service=evidence_service,
    report_service=report_service,
    db=db,
    websocket_manager=ws_manager
)


@router.post("")
async def create_investigation(
    request: InvestigationCreate,
    background_tasks: BackgroundTasks
):

    try:
        inv_id = f"INV-{uuid.uuid4().hex[:6].upper()}"

        investigation = {
            "id": inv_id,
            "case_id": request.case_id,
            "source_wallet": request.source_wallet,
            "chain": request.chain,
            "max_hops": request.max_hops,
            "min_transfer_value": request.min_transfer_value,
            "time_window_days": request.time_window_days,
            "assets": request.assets,
            "status": "CREATED"
        }

        # Save investigation using repository
        db.save_investigation(investigation)

        # Start orchestrator in background task
        background_tasks.add_task(orchestrator.run, investigation)

        return investigation

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=str(exc)
        )


@router.get("")
async def list_investigations():
    return db.list_investigations()


@router.get("/{investigation_id}")
async def get_investigation(
    investigation_id: str
):

    investigation = db.get_investigation(
        investigation_id
    )

    if not investigation:

        raise HTTPException(
            status_code=404,
            detail="Investigation not found"
        )

    return investigation


@router.get("/{investigation_id}/report/html", response_class=HTMLResponse)
async def get_investigation_html_report(
    investigation_id: str
):

    investigation = db.get_investigation(investigation_id)

    if not investigation:
        raise HTTPException(status_code=404, detail="Investigation not found")

    report_id = f"RPT-{investigation_id}"
    report = db.get_report(report_id)

    if not report:
        report = report_service.generate_report(investigation)

    return generate_html_report(report)
