import uuid
from datetime import datetime, timezone
from fastapi import APIRouter, HTTPException
from app.schemas.case import CaseCreate, CaseResponse
from app.repositories.db import db

router = APIRouter()


@router.get("", response_model=list[CaseResponse])
async def list_cases():
    return db.get_cases()


@router.post("", response_model=CaseResponse)
async def create_case(request: CaseCreate):
    case_id = f"CASE-{uuid.uuid4().hex[:4].upper()}"
    new_case = {
        "id": case_id,
        "title": request.title,
        "description": request.description or "",
        "status": "OPEN",
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    db.save_case(new_case)
    return new_case
