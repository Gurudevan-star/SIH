from fastapi import APIRouter, HTTPException
from app.schemas.monitoring import MonitoringCheckRequest
from app.repositories.db import db
from app.providers.blockchain import BlockchainProvider
from app.services.risk_service import RiskService
from app.services.monitoring_service import MonitoringService

router = APIRouter()

blockchain_provider = BlockchainProvider()
risk_service = RiskService()
monitoring_service = MonitoringService(
    blockchain_provider=blockchain_provider,
    risk_service=risk_service,
    db=db
)


@router.post("/monitoring/check")
async def check_monitored_wallet(request: MonitoringCheckRequest):
    try:
        result = await monitoring_service.check_wallet(
            wallet_address=request.wallet_address,
            chain=request.chain
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/monitoring/alerts")
async def get_monitoring_alerts(wallet: str = None):
    return db.get_alerts(wallet)
