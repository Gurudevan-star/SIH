from decimal import Decimal
from typing import List, Optional
from pydantic import BaseModel, Field


class InvestigationCreate(BaseModel):

    case_id: str = "CASE-001"

    source_wallet: str

    chain: str = "ethereum"

    max_hops: int = Field(
        default=5,
        ge=1,
        le=20
    )

    min_transfer_value: Decimal = Field(
        default=Decimal("0.0"),
        ge=Decimal("0.0")
    )

    time_window_days: int = Field(
        default=30,
        ge=1,
        le=3650
    )

    assets: List[str] = []


class InvestigationResponse(BaseModel):
    id: str
    case_id: str
    source_wallet: str
    chain: str
    max_hops: int
    min_transfer_value: Decimal
    time_window_days: int
    assets: List[str]
    status: str
