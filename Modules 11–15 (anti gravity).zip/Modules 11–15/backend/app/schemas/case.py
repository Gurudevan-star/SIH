from typing import Optional
from pydantic import BaseModel


class CaseCreate(BaseModel):
    title: str
    description: Optional[str] = ""


class CaseResponse(BaseModel):
    id: str
    title: str
    description: Optional[str] = ""
    status: str
    created_at: str
