from pydantic import BaseModel


class MonitoringCheckRequest(BaseModel):
    wallet_address: str
    chain: str = "ethereum"
