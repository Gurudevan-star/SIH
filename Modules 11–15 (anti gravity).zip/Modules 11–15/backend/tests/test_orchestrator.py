import pytest
import asyncio
from decimal import Decimal

from app.repositories.db import db
from app.providers.blockchain import BlockchainProvider
from app.providers.exchange import ExchangeProvider
from app.services.wallet_service import WalletService
from app.services.acquisition_service import AcquisitionService
from app.services.normalization_service import NormalizationService
from app.services.graph_service import GraphService
from app.services.clustering_service import ClusteringService
from app.services.exchange_service import ExchangeService
from app.services.risk_service import RiskService
from app.services.evidence_service import EvidenceService
from app.services.report_service import ReportService
from app.services.investigation_orchestrator import InvestigationOrchestrator


@pytest.mark.asyncio
async def test_investigation_orchestrator_flow():
    bp = BlockchainProvider()
    ep = ExchangeProvider()
    
    orchestrator = InvestigationOrchestrator(
        wallet_service=WalletService(),
        acquisition_service=AcquisitionService(bp),
        normalization_service=NormalizationService(),
        graph_service=GraphService(),
        clustering_service=ClusteringService(),
        exchange_service=ExchangeService(ep),
        risk_service=RiskService(),
        evidence_service=EvidenceService(),
        report_service=ReportService(db),
        db=db
    )

    inv_input = {
        "id": "INV-TEST-001",
        "case_id": "CASE-001",
        "source_wallet": "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
        "chain": "ethereum",
        "max_hops": 3,
        "min_transfer_value": Decimal("0.0"),
        "time_window_days": 30,
        "assets": ["ETH"]
    }

    result = await orchestrator.run(inv_input)

    assert result is not None
    assert result["investigation"]["id"] == "INV-TEST-001"
    assert "report" in result
    assert result["risk_assessment"]["risk_score"] > 0
    assert db.get_investigation("INV-TEST-001")["investigation"]["status"] == "COMPLETED"
