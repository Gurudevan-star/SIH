import pytest
from app.repositories.db import db
from app.providers.blockchain import BlockchainProvider
from app.services.risk_service import RiskService
from app.services.monitoring_service import MonitoringService


@pytest.mark.asyncio
async def test_monitoring_service():
    bp = BlockchainProvider()
    rs = RiskService()
    ms = MonitoringService(blockchain_provider=bp, risk_service=rs, db=db)

    result = await ms.check_wallet("0x71C7656EC7ab88b098defB751B7401B5f6d8976F", "ethereum")

    assert "wallet" in result
    assert "new_transactions" in result
    assert "alerts" in result
