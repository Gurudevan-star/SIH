import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Dashboard from './pages/Dashboard';
import NewInvestigation from './pages/NewInvestigation';
import InvestigationWorkspace from './pages/InvestigationWorkspace';
import Report from './pages/Report';

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [selectedInvId, setSelectedInvId] = useState(null);

  const handleSelectInvestigation = (id) => {
    setSelectedInvId(id);
    setActiveTab('workspace');
  };

  const handleInvestigationCreated = (id) => {
    setSelectedInvId(id);
    setActiveTab('workspace');
  };

  const handleViewReport = (id) => {
    setSelectedInvId(id);
    setActiveTab('report');
  };

  return (
    <div className="app-container">
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />

      <main className="main-content">
        {activeTab === 'dashboard' && (
          <Dashboard
            onSelectInvestigation={handleSelectInvestigation}
            onNewClick={() => setActiveTab('new')}
          />
        )}

        {activeTab === 'new' && (
          <NewInvestigation
            onInvestigationCreated={handleInvestigationCreated}
          />
        )}

        {activeTab === 'workspace' && (
          <InvestigationWorkspace
            investigationId={selectedInvId || 'INV-001'}
            onBack={() => setActiveTab('dashboard')}
            onViewReport={handleViewReport}
          />
        )}

        {activeTab === 'report' && (
          <Report
            investigationId={selectedInvId || 'INV-001'}
            onBack={() => setActiveTab('workspace')}
          />
        )}
      </main>
    </div>
  );
}
