import React from 'react';
import { Check, Loader2 } from 'lucide-react';

const STEPS = [
  "VALIDATING",
  "FETCHING_DATA",
  "NORMALIZING",
  "TRACING",
  "CLUSTERING",
  "MATCHING",
  "SCORING",
  "EVIDENCE",
  "COMPLETED"
];

export default function InvestigationStatus({ currentStatus }) {
  const currentIndex = STEPS.indexOf(currentStatus);

  return (
    <div className="panel">
      <div className="panel-title">
        <span>Investigation Execution Pipeline</span>
        <span className="badge badge-low" style={{ background: currentStatus === 'COMPLETED' ? 'rgba(16,185,129,0.15)' : 'rgba(0,242,254,0.15)', color: currentStatus === 'COMPLETED' ? '#10b981' : '#00f2fe' }}>
          {currentStatus || 'INITIATING'}
        </span>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px', overflowX: 'auto', padding: '16px 0' }}>
        {STEPS.map((step, idx) => {
          const isDone = currentIndex > idx || currentStatus === 'COMPLETED';
          const isCurrent = currentIndex === idx && currentStatus !== 'COMPLETED';

          let stepColor = 'var(--text-muted)';
          let borderColor = 'var(--border-color)';
          let bg = 'transparent';

          if (isDone) {
            stepColor = '#10b981';
            borderColor = '#10b981';
            bg = 'rgba(16, 185, 129, 0.1)';
          } else if (isCurrent) {
            stepColor = '#00f2fe';
            borderColor = '#00f2fe';
            bg = 'rgba(0, 242, 254, 0.1)';
          }

          return (
            <div key={step} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px', minWidth: '90px' }}>
              <div style={{
                width: '32px',
                height: '32px',
                borderRadius: '50%',
                border: `2px solid ${borderColor}`,
                background: bg,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: stepColor,
                fontWeight: 700,
                fontSize: '0.8rem'
              }}>
                {isDone ? <Check size={16} /> : isCurrent ? <Loader2 size={16} className="spin" style={{ animation: 'spin 1.5s linear infinite' }} /> : (idx + 1)}
              </div>
              <span style={{ fontSize: '0.65rem', fontWeight: 700, color: stepColor, textAlign: 'center' }}>
                {step.replace('_', ' ')}
              </span>
            </div>
          );
        })}
      </div>
      <style>{`
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}
