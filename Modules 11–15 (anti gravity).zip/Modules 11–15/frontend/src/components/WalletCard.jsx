import React, { useState } from 'react';
import { Wallet, Copy, Check, ExternalLink } from 'lucide-react';

export default function WalletCard({ sourceWallet, chain }) {
  const [copied, setCopied] = useState(false);

  const copyAddress = () => {
    if (sourceWallet) {
      navigator.clipboard.writeText(sourceWallet);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="panel">
      <div className="panel-title">
        <span>Subject Wallet Overview</span>
        <Wallet size={20} color="var(--accent-cyan)" />
      </div>

      <div style={{ margin: '16px 0' }}>
        <span style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', textTransform: 'uppercase', display: 'block', marginBottom: '4px' }}>
          Blockchain Network
        </span>
        <span className="badge badge-low" style={{ background: 'rgba(0,242,254,0.1)', color: '#00f2fe', borderColor: '#00f2fe' }}>
          {chain ? chain.toUpperCase() : 'ETHEREUM'}
        </span>
      </div>

      <div style={{ marginTop: '16px' }}>
        <span style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', textTransform: 'uppercase', display: 'block', marginBottom: '6px' }}>
          Address
        </span>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', background: 'rgba(15, 23, 42, 0.8)', padding: '10px 14px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
          <code style={{ fontSize: '0.85rem', color: '#38bdf8', wordBreak: 'break-all', flex: 1 }}>
            {sourceWallet || 'N/A'}
          </code>
          <button onClick={copyAddress} style={{ background: 'none', border: 'none', color: 'var(--text-secondary)', cursor: 'pointer' }}>
            {copied ? <Check size={16} color="#10b981" /> : <Copy size={16} />}
          </button>
        </div>
      </div>
    </div>
  );
}
