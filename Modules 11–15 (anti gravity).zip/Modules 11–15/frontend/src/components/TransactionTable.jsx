import React, { useState } from 'react';
import { ArrowUpRight, ArrowDownLeft, Search } from 'lucide-react';

export default function TransactionTable({ transactions = [] }) {
  const [filter, setFilter] = useState('');

  const filteredTxs = transactions.filter(tx =>
    (tx.transaction_hash || '').toLowerCase().includes(filter.toLowerCase()) ||
    (tx.sender || '').toLowerCase().includes(filter.toLowerCase()) ||
    (tx.receiver || '').toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <div className="panel">
      <div className="panel-title">
        <span>Observed Ledger Transactions ({transactions.length})</span>
        <div style={{ position: 'relative', width: '240px' }}>
          <input
            type="text"
            className="form-control"
            placeholder="Filter hash or address..."
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            style={{ paddingLeft: '32px', fontSize: '0.8rem', padding: '6px 12px 6px 32px' }}
          />
          <Search size={14} style={{ position: 'absolute', left: '10px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
        </div>
      </div>

      <div style={{ overflowX: 'auto' }}>
        <table className="data-table">
          <thead>
            <tr>
              <th>Hash</th>
              <th>Chain</th>
              <th>Sender (From)</th>
              <th>Receiver (To)</th>
              <th>Amount</th>
              <th>Asset</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {filteredTxs.length === 0 ? (
              <tr>
                <td colSpan="7" style={{ textAlign: 'center', color: 'var(--text-muted)', padding: '24px' }}>
                  No transactions recorded.
                </td>
              </tr>
            ) : (
              filteredTxs.map((tx, idx) => (
                <tr key={tx.transaction_hash || idx}>
                  <td>
                    <code style={{ fontSize: '0.78rem', color: '#38bdf8' }}>
                      {(tx.transaction_hash || '').slice(0, 10)}...{(tx.transaction_hash || '').slice(-6)}
                    </code>
                  </td>
                  <td><span className="badge badge-low">{tx.chain || 'ETH'}</span></td>
                  <td>
                    <code style={{ fontSize: '0.78rem', color: 'var(--text-secondary)' }}>
                      {(tx.sender || '').slice(0, 8)}...{(tx.sender || '').slice(-4)}
                    </code>
                  </td>
                  <td>
                    <code style={{ fontSize: '0.78rem', color: 'var(--text-secondary)' }}>
                      {(tx.receiver || '').slice(0, 8)}...{(tx.receiver || '').slice(-4)}
                    </code>
                  </td>
                  <td style={{ fontWeight: 700, color: '#f8fafc' }}>
                    {String(tx.amount || '0')}
                  </td>
                  <td><span style={{ fontSize: '0.8rem', color: 'var(--accent-cyan)' }}>{tx.asset || 'ETH'}</span></td>
                  <td>
                    <span className="badge badge-low">
                      {tx.status || 'CONFIRMED'}
                    </span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
