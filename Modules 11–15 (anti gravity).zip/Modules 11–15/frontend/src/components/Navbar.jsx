import React from 'react';
import { Shield, Activity, PlusCircle, LayoutDashboard, FileText } from 'lucide-react';

export default function Navbar({ activeTab, setActiveTab }) {
  return (
    <nav className="navbar">
      <a href="#" onClick={() => setActiveTab('dashboard')} className="brand">
        <Shield className="brand-icon" />
        <span>CryptoTrace <span style={{ color: '#00f2fe', fontSize: '0.8rem', fontWeight: 600 }}>FORENSICS</span></span>
      </a>
      <ul className="nav-links">
        <li>
          <a
            href="#"
            className={activeTab === 'dashboard' ? 'active' : ''}
            onClick={(e) => { e.preventDefault(); setActiveTab('dashboard'); }}
          >
            <LayoutDashboard size={16} style={{ verticalAlign: 'middle', marginRight: 6 }} />
            Dashboard
          </a>
        </li>
        <li>
          <a
            href="#"
            className={activeTab === 'new' ? 'active' : ''}
            onClick={(e) => { e.preventDefault(); setActiveTab('new'); }}
          >
            <PlusCircle size={16} style={{ verticalAlign: 'middle', marginRight: 6 }} />
            New Investigation
          </a>
        </li>
      </ul>
    </nav>
  );
}
