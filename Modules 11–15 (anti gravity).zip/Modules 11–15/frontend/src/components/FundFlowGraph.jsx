import React from 'react';
import { GitCommit, Network } from 'lucide-react';

export default function FundFlowGraph({ fundFlow, sourceWallet }) {
  const paths = fundFlow?.traced_paths || [
    {
      path_id: "PATH-1",
      hops: [sourceWallet || "0x71C7656EC7ab88b098defB751B7401B5f6d8976F", "0x28C6c06298d514Db089934071355E5743bf21d60", "0xdAC17F958D2ee523a2206206994597C13D831ec7"],
      total_flow: 140.0,
      terminal_entity: "Binance / Tether Contract"
    },
    {
      path_id: "PATH-2",
      hops: [sourceWallet || "0x71C7656EC7ab88b098defB751B7401B5f6d8976F", "0x28C6c06298d514Db089934071355E5743bf21d60", "0x12D66f87A04A9E220743712cE6d9bB1B5616B8Fc"],
      total_flow: 5.0,
      terminal_entity: "Tornado Cash Router"
    }
  ];

  return (
    <div className="panel">
      <div className="panel-title">
        <span>Visual Multi-Hop Fund Flow Graph</span>
        <Network size={20} color="var(--accent-cyan)" />
      </div>

      <div style={{ background: '#090d16', borderRadius: '8px', padding: '24px', border: '1px solid var(--border-color)', minHeight: '260px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
        {paths.map((p, idx) => (
          <div key={p.path_id || idx} style={{ display: 'flex', alignItems: 'center', gap: '16px', flexWrap: 'wrap' }}>
            <span style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--accent-blue)', minWidth: '60px' }}>
              {p.path_id}
            </span>
            
            {p.hops.map((hopAddress, hopIdx) => {
              const isSource = hopIdx === 0;
              const isMixer = hopAddress.toLowerCase().includes('12d6');
              const isExchange = hopAddress.toLowerCase().includes('28c6') || hopAddress.toLowerCase().includes('dac1');

              let nodeBg = 'rgba(255,255,255,0.05)';
              let borderColor = 'var(--border-color)';
              let textColor = '#38bdf8';
              let tag = `Hop ${hopIdx}`;

              if (isSource) {
                nodeBg = 'rgba(239, 68, 68, 0.15)';
                borderColor = '#ef4444';
                textColor = '#ef4444';
                tag = 'Subject';
              } else if (isMixer) {
                nodeBg = 'rgba(239, 68, 68, 0.2)';
                borderColor = '#ef4444';
                textColor = '#ef4444';
                tag = 'Mixer';
              } else if (isExchange) {
                nodeBg = 'rgba(16, 185, 129, 0.15)';
                borderColor = '#10b981';
                textColor = '#10b981';
                tag = 'Exchange';
              }

              return (
                <React.Fragment key={hopAddress + hopIdx}>
                  <div style={{
                    background: nodeBg,
                    border: `1px solid ${borderColor}`,
                    padding: '8px 14px',
                    borderRadius: '8px',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'flex-start'
                  }}>
                    <span style={{ fontSize: '0.65rem', textTransform: 'uppercase', color: textColor, fontWeight: 800 }}>
                      {tag}
                    </span>
                    <code style={{ fontSize: '0.75rem', color: 'var(--text-primary)' }}>
                      {hopAddress.slice(0, 6)}...{hopAddress.slice(-4)}
                    </code>
                  </div>

                  {hopIdx < p.hops.length - 1 && (
                    <div style={{ display: 'flex', alignItems: 'center', color: 'var(--accent-cyan)', fontSize: '0.8rem', gap: '4px' }}>
                      <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>➔ {p.total_flow} ETH ➔</span>
                    </div>
                  )}
                </React.Fragment>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}
