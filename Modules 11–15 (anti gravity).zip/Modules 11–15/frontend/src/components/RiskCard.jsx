import React from 'react';
import { AlertTriangle, ShieldAlert, CheckCircle } from 'lucide-react';

export default function RiskCard({ riskAssessment }) {
  if (!riskAssessment) return null;

  const score = riskAssessment.risk_score || 0;
  const level = riskAssessment.risk_level || 'UNKNOWN';

  let badgeClass = 'badge-low';
  let icon = <CheckCircle size={20} color="#10b981" />;

  if (level === 'CRITICAL' || level === 'HIGH') {
    badgeClass = 'badge-critical';
    icon = <ShieldAlert size={20} color="#ef4444" />;
  } else if (level === 'MEDIUM') {
    badgeClass = 'badge-medium';
    icon = <AlertTriangle size={20} color="#f59e0b" />;
  }

  return (
    <div className="panel">
      <div className="panel-title">
        <span>Risk Assessment</span>
        {icon}
      </div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: '12px', margin: '16px 0' }}>
        <h2 style={{ fontSize: '3rem', fontWeight: 800, color: score >= 70 ? '#ef4444' : score >= 40 ? '#f59e0b' : '#10b981' }}>
          {score}
        </h2>
        <span style={{ fontSize: '1.25rem', color: 'var(--text-muted)' }}>/ 100</span>
        <span className={`badge ${badgeClass}`} style={{ fontSize: '0.9rem', padding: '6px 14px' }}>
          {level} RISK
        </span>
      </div>

      <div style={{ marginTop: '16px' }}>
        <h4 style={{ color: 'var(--text-secondary)', fontSize: '0.8rem', textTransform: 'uppercase', marginBottom: '8px' }}>
          Risk Signals Detected
        </h4>
        <ul style={{ listStyle: 'none' }}>
          {riskAssessment.sanctioned_exposure && (
            <li style={{ color: '#ef4444', fontSize: '0.875rem', marginBottom: '4px' }}>
              ⚠️ Direct interaction with OFAC sanctioned wallet
            </li>
          )}
          {riskAssessment.mixer_exposure && (
            <li style={{ color: '#ef4444', fontSize: '0.875rem', marginBottom: '4px' }}>
              🌀 Privacy Mixer interaction (Tornado Cash Router)
            </li>
          )}
          {riskAssessment.illicit_exposure && (
            <li style={{ color: '#f59e0b', fontSize: '0.875rem', marginBottom: '4px' }}>
              🕵️ Suspected Lazarus Group cluster connection
            </li>
          )}
          {!riskAssessment.sanctioned_exposure && !riskAssessment.mixer_exposure && !riskAssessment.illicit_exposure && (
            <li style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>
              No critical threat signatures identified.
            </li>
          )}
        </ul>
      </div>
    </div>
  );
}
