import React from 'react';
import { Bell, AlertOctagon } from 'lucide-react';

export default function AlertPanel({ alerts = [] }) {
  return (
    <div className="panel">
      <div className="panel-title">
        <span>Real-Time Monitoring Live Feed ({alerts.length})</span>
        <Bell size={20} color="var(--accent-amber)" />
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
        {alerts.length === 0 ? (
          <div style={{ color: 'var(--text-muted)', fontSize: '0.875rem', textAlign: 'center', padding: '16px' }}>
            No high-risk WebSocket alerts emitted yet.
          </div>
        ) : (
          alerts.map((al, idx) => (
            <div key={idx} style={{
              background: 'rgba(239, 68, 68, 0.1)',
              border: '1px solid rgba(239, 68, 68, 0.3)',
              borderRadius: '8px',
              padding: '12px 16px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <AlertOctagon size={18} color="#ef4444" />
                <div>
                  <div style={{ fontWeight: 700, fontSize: '0.85rem', color: '#ef4444' }}>
                    {al.alert_type || 'NEW_HIGH_RISK_TRANSACTION'}
                  </div>
                  <div style={{ fontSize: '0.78rem', color: 'var(--text-secondary)' }}>
                    Wallet: <code style={{ color: '#38bdf8' }}>{al.wallet || 'N/A'}</code> | Tx: <code>{(al.transaction_hash || '').slice(0, 10)}...</code>
                  </div>
                </div>
              </div>
              <span className="badge badge-critical">
                Score {al.risk_score || 95}
              </span>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
