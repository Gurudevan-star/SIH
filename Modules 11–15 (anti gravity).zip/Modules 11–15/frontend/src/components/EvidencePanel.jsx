import React from 'react';
import { FileCheck, Lock, CheckCircle2 } from 'lucide-react';

export default function EvidencePanel({ evidence = [] }) {
  return (
    <div className="panel">
      <div className="panel-title">
        <span>Forensic Evidence Audit Trail ({evidence.length})</span>
        <FileCheck size={20} color="var(--accent-emerald)" />
      </div>

      <div style={{ overflowX: 'auto' }}>
        <table className="data-table">
          <thead>
            <tr>
              <th>Evidence ID</th>
              <th>Type</th>
              <th>Description</th>
              <th>Timestamp (UTC)</th>
              <th>Merkle Verification Hash</th>
              <th>Custody</th>
            </tr>
          </thead>
          <tbody>
            {evidence.length === 0 ? (
              <tr>
                <td colSpan="6" style={{ textAlign: 'center', color: 'var(--text-muted)', padding: '24px' }}>
                  No evidence log compiled yet.
                </td>
              </tr>
            ) : (
              evidence.map((ev, idx) => (
                <tr key={ev.evidence_id || idx}>
                  <td style={{ fontWeight: 700, color: 'var(--accent-cyan)' }}>{ev.evidence_id}</td>
                  <td><span className="badge badge-low">{ev.type}</span></td>
                  <td style={{ color: 'var(--text-secondary)' }}>{ev.description}</td>
                  <td style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>{ev.timestamp}</td>
                  <td>
                    <code style={{ fontSize: '0.75rem', color: '#38bdf8' }}>
                      {(ev.verification_hash || '').slice(0, 16)}...
                    </code>
                  </td>
                  <td>
                    <span style={{ color: '#10b981', fontSize: '0.8rem', display: 'flex', alignItems: 'center', gap: '4px' }}>
                      <CheckCircle2 size={14} /> Verified
                    </span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
