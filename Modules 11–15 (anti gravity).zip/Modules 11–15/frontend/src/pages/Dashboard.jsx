import React, { useEffect, useState } from 'react';
import { listInvestigations, getAlerts, checkWallet } from '../api/cryptotrace';
import AlertPanel from '../components/AlertPanel';
import { Activity, ShieldCheck, Cpu, ArrowRight } from 'lucide-react';

export default function Dashboard({ onSelectInvestigation, onNewClick }) {
  const [investigations, setInvestigations] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboard();
  }, []);

  async function loadDashboard() {
    try {
      const invs = await listInvestigations();
      const alts = await getAlerts();
      setInvestigations(invs || []);
      setAlerts(alts || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }

  const triggerMonitoringCheck = async () => {
    try {
      await checkWallet("0x71C7656EC7ab88b098defB751B7401B5f6d8976F", "ethereum");
      loadDashboard();
    } catch (e) {
      alert("Monitoring check failed: " + e.message);
    }
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
        <div>
          <h1 style={{ fontSize: '1.75rem', fontWeight: 800 }}>Forensic Operations Dashboard</h1>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem' }}>Real-time threat monitoring and active case telemetry</p>
        </div>
        <div style={{ display: 'flex', gap: '12px' }}>
          <button className="btn btn-secondary" onClick={triggerMonitoringCheck}>
            <Activity size={16} /> Run Monitoring Check
          </button>
          <button className="btn" onClick={onNewClick}>
            + Start Investigation
          </button>
        </div>
      </div>

      <div className="grid-3" style={{ marginBottom: '24px' }}>
        <div className="panel" style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <div style={{ background: 'rgba(0,242,254,0.1)', padding: '12px', borderRadius: '10px' }}>
            <Cpu size={24} color="#00f2fe" />
          </div>
          <div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Active Traces</div>
            <div style={{ fontSize: '1.5rem', fontWeight: 800 }}>{investigations.length}</div>
          </div>
        </div>

        <div className="panel" style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <div style={{ background: 'rgba(239,68,68,0.1)', padding: '12px', borderRadius: '10px' }}>
            <Activity size={24} color="#ef4444" />
          </div>
          <div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>High Risk Alerts</div>
            <div style={{ fontSize: '1.5rem', fontWeight: 800 }}>{alerts.length}</div>
          </div>
        </div>

        <div className="panel" style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <div style={{ background: 'rgba(16,185,129,0.1)', padding: '12px', borderRadius: '10px' }}>
            <ShieldCheck size={24} color="#10b981" />
          </div>
          <div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>System Health</div>
            <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#10b981' }}>100% OPERATIONAL</div>
          </div>
        </div>
      </div>

      <div className="grid-2">
        <div className="panel">
          <div className="panel-title">
            <span>Recent Investigations</span>
          </div>

          <table className="data-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Subject Wallet</th>
                <th>Chain</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {investigations.length === 0 ? (
                <tr>
                  <td colSpan="5" style={{ textAlign: 'center', color: 'var(--text-muted)' }}>No investigations launched yet.</td>
                </tr>
              ) : (
                investigations.map(inv => (
                  <tr key={inv.id}>
                    <td><strong style={{ color: 'var(--accent-cyan)' }}>{inv.id}</strong></td>
                    <td><code>{(inv.source_wallet || '').slice(0, 10)}...</code></td>
                    <td><span className="badge badge-low">{inv.chain}</span></td>
                    <td>
                      <span className={`badge ${inv.status === 'COMPLETED' ? 'badge-low' : 'badge-medium'}`}>
                        {inv.status}
                      </span>
                    </td>
                    <td>
                      <button className="btn btn-secondary" style={{ padding: '4px 10px', fontSize: '0.75rem' }} onClick={() => onSelectInvestigation(inv.id)}>
                        Open Workspace <ArrowRight size={12} />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <AlertPanel alerts={alerts} />
      </div>
    </div>
  );
}
