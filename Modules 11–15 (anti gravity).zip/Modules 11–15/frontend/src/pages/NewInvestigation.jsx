import React, { useState } from "react";
import { createInvestigation } from "../api/cryptotrace";
import { Search, ShieldAlert, Sparkles } from "lucide-react";

export default function NewInvestigation({ onInvestigationCreated }) {
  const [wallet, setWallet] = useState("0x71C7656EC7ab88b098defB751B7401B5f6d8976F");
  const [chain, setChain] = useState("ethereum");
  const [hops, setHops] = useState(5);
  const [minTransfer, setMinTransfer] = useState(0);
  const [loading, setLoading] = useState(false);

  async function startInvestigation(e) {
    e.preventDefault();

    if (!wallet.trim()) {
      alert("Enter a wallet address");
      return;
    }

    setLoading(true);

    try {
      const result = await createInvestigation({
        case_id: "CASE-001",
        source_wallet: wallet.trim(),
        chain: chain,
        max_hops: Number(hops),
        min_transfer_value: Number(minTransfer),
        time_window_days: 30,
        assets: []
      });

      if (onInvestigationCreated) {
        onInvestigationCreated(result.id);
      } else {
        window.location.href = `/investigation/${result.id}`;
      }

    } catch (error) {
      alert(error.message);
    } finally {
      setLoading(false);
    }
  }

  const fillPreset = (addr) => {
    setWallet(addr);
  };

  return (
    <div style={{ maxWidth: '720px', margin: '0 auto' }}>
      <div className="panel">
        <div style={{ marginBottom: '24px' }}>
          <h1 style={{ fontSize: '1.5rem', fontWeight: 800 }}>Start New Blockchain Investigation</h1>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.875rem' }}>
            Configure target address, multi-hop recursion depth, and asset filtering parameters.
          </p>
        </div>

        <form onSubmit={startInvestigation}>
          <div className="form-group">
            <label>Subject Wallet Address</label>
            <input
              className="form-control mono"
              value={wallet}
              onChange={e => setWallet(e.target.value)}
              placeholder="0x..."
              required
            />
            <div style={{ display: 'flex', gap: '8px', marginTop: '8px', flexWrap: 'wrap' }}>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Quick Presets:</span>
              <button
                type="button"
                onClick={() => fillPreset("0x71C7656EC7ab88b098defB751B7401B5f6d8976F")}
                style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid #ef4444', color: '#ef4444', padding: '2px 8px', borderRadius: '4px', fontSize: '0.7rem', cursor: 'pointer' }}
              >
                🚨 Lazarus Suspect
              </button>
              <button
                type="button"
                onClick={() => fillPreset("0x28C6c06298d514Db089934071355E5743bf21d60")}
                style={{ background: 'rgba(16,185,129,0.1)', border: '1px solid #10b981', color: '#10b981', padding: '2px 8px', borderRadius: '4px', fontSize: '0.7rem', cursor: 'pointer' }}
              >
                🏦 Binance Deposit Node
              </button>
            </div>
          </div>

          <div className="grid-2">
            <div className="form-group">
              <label>Blockchain Network</label>
              <select
                className="form-control"
                value={chain}
                onChange={e => setChain(e.target.value)}
              >
                <option value="ethereum">Ethereum (ETH)</option>
                <option value="polygon">Polygon (MATIC)</option>
                <option value="bsc">BNB Smart Chain (BSC)</option>
              </select>
            </div>

            <div className="form-group">
              <label>Maximum Tracing Hops (1 - 20)</label>
              <input
                type="number"
                min="1"
                max="20"
                className="form-control"
                value={hops}
                onChange={e => setHops(e.target.value)}
              />
            </div>
          </div>

          <div className="form-group">
            <label>Minimum Transfer Value Threshold</label>
            <input
              type="number"
              step="0.01"
              min="0"
              className="form-control"
              value={minTransfer}
              onChange={e => setMinTransfer(e.target.value)}
            />
          </div>

          <button
            type="submit"
            className="btn"
            disabled={loading}
            style={{ width: '100%', justifyContent: 'center', marginTop: '12px' }}
          >
            {loading ? "Initiating Forensics Engine..." : "🚀 Launch Investigation"}
          </button>
        </form>
      </div>
    </div>
  );
}
