import React, { useEffect, useState } from 'react';
import { getInvestigation } from '../api/cryptotrace';
import { Printer, Download, ArrowLeft, ExternalLink } from 'lucide-react';

export default function Report({ investigationId, onBack }) {
  const [data, setData] = useState(null);

  useEffect(() => {
    if (investigationId) {
      getInvestigation(investigationId).then(setData).catch(console.error);
    }
  }, [investigationId]);

  const reportUrl = `http://localhost:8000/api/investigations/${investigationId}/report/html`;

  return (
    <div style={{ maxWidth: '1000px', margin: '0 auto' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
        <button className="btn btn-secondary" onClick={onBack}>
          <ArrowLeft size={16} /> Back to Workspace
        </button>

        <div style={{ display: 'flex', gap: '12px' }}>
          <a href={reportUrl} target="_blank" rel="noopener noreferrer" className="btn btn-secondary">
            <ExternalLink size={16} /> Open Standalone HTML
          </a>
          <button className="btn" onClick={() => window.print()}>
            <Printer size={16} /> Print / Save PDF
          </button>
        </div>
      </div>

      <div className="panel" style={{ background: '#fff', color: '#0f172a', border: '1px solid #e2e8f0', minHeight: '600px' }}>
        <iframe
          src={reportUrl}
          title="Forensic Report HTML"
          style={{ width: '100%', height: '800px', border: 'none' }}
        />
      </div>
    </div>
  );
}
