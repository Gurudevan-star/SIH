import React, { useEffect, useState } from "react";
import { getInvestigation } from "../api/cryptotrace";
import RiskCard from "../components/RiskCard";
import WalletCard from "../components/WalletCard";
import TransactionTable from "../components/TransactionTable";
import FundFlowGraph from "../components/FundFlowGraph";
import EvidencePanel from "../components/EvidencePanel";
import AlertPanel from "../components/AlertPanel";
import InvestigationStatus from "../components/InvestigationStatus";
import { FileText, RefreshCw, ArrowLeft } from "lucide-react";

export function useInvestigationSocket(investigationId) {
  const [alerts, setAlerts] = useState([]);

  useEffect(() => {
    if (!investigationId) return;

    const wsUrl = `ws://localhost:8000/ws/investigations/${investigationId}`;
    let socket;

    try {
      socket = new WebSocket(wsUrl);

      socket.onopen = () => {
        console.log("CryptoTrace WebSocket connected");
        socket.send("subscribe");
      };

      socket.onmessage = event => {
        try {
          const message = JSON.parse(event.data);
          setAlerts(previous => [message, ...previous]);
        } catch (e) {
          console.error("WS JSON parse error", e);
        }
      };

      socket.onerror = error => {
        console.error("WebSocket error", error);
      };

      socket.onclose = () => {
        console.log("WebSocket disconnected");
      };
    } catch (err) {
      console.warn("WebSocket connection skipped or unavailable:", err);
    }

    return () => {
      if (socket) socket.close();
    };
  }, [investigationId]);

  return alerts;
}

export default function InvestigationWorkspace({ investigationId, onBack, onViewReport }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  const wsAlerts = useInvestigationSocket(investigationId);

  useEffect(() => {
    loadInvestigation();

    const interval = setInterval(loadInvestigation, 3000);
    return () => clearInterval(interval);
  }, [investigationId]);

  async function loadInvestigation() {
    try {
      const result = await getInvestigation(investigationId);
      setData(result);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  }

  if (loading && !data) {
    return (
      <div style={{ padding: '60px', textAlign: 'center', color: 'var(--text-secondary)' }}>
        <RefreshCw className="spin" size={32} style={{ marginBottom: '16px', color: 'var(--accent-cyan)' }} />
        <div>Connecting to CryptoTrace Forensics Engine...</div>
      </div>
    );
  }

  const invObj = data?.investigation || {};
  const status = invObj.status || data?.status || "UNKNOWN";
  const sourceWallet = data?.source_wallet || invObj.source_wallet || "";
  const chain = invObj.chain || "ethereum";

  return (
    <div className="workspace">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
        <div>
          <button className="btn btn-secondary" onClick={onBack} style={{ marginBottom: '12px', padding: '6px 12px', fontSize: '0.8rem' }}>
            <ArrowLeft size={14} /> Back to Dashboard
          </button>
          <h1 style={{ fontSize: '1.75rem', fontWeight: 800 }}>Investigation Workspace</h1>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.875rem' }}>
            Investigation ID: <strong style={{ color: 'var(--accent-cyan)' }}>{investigationId}</strong>
          </p>
        </div>

        <button className="btn" onClick={() => onViewReport(investigationId)}>
          <FileText size={16} /> View Forensic Report
        </button>
      </div>

      {/* Stepper Status */}
      <InvestigationStatus currentStatus={status} />

      {/* Overview Cards Grid */}
      <div className="grid-2">
        <WalletCard sourceWallet={sourceWallet} chain={chain} />
        <RiskCard riskAssessment={data?.risk_assessment} />
      </div>

      {/* Visual Multi-Hop Fund Flow Graph */}
      <FundFlowGraph fundFlow={data?.fund_flow} sourceWallet={sourceWallet} />

      {/* Transaction Ledger Table */}
      <TransactionTable transactions={data?.transactions || []} />

      {/* Evidence & Live WebSocket Alerts */}
      <div className="grid-2">
        <EvidencePanel evidence={data?.evidence || []} />
        <AlertPanel alerts={wsAlerts} />
      </div>
    </div>
  );
}
