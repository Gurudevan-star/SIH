# CryptoTrace - Blockchain Forensics and Investigation Platform

CryptoTrace is a full-stack, enterprise-grade blockchain analytics and forensics platform designed for law enforcement, AML compliance officers, and threat intelligence analysts. It offers automated multi-hop transaction tracing, entity attribution, address clustering heuristics, risk scoring, real-time monitoring, and tamper-evident evidence generation.

---

## 🌟 Key Features

- **Multi-Hop Fund Flow Tracing**: Recursively trace cryptocurrency movements across multiple address hops.
- **Address Clustering**: Multi-input co-spending, change detection, and deposit address reuse heuristics.
- **VASP & Exchange Intelligence**: Match wallet nodes against known exchange cold/hot wallets, mixers (e.g., Tornado Cash), and sanctioned entities.
- **Precise Financial Analytics**: Powered by Python `Decimal` data types to prevent floating-point precision loss.
- **Real-Time Monitoring & Alerts**: Monitored wallet activity via WebSockets with instant alerts for high-risk activity (Risk Score $\ge$ 70).
- **Automated HTML Forensic Reports**: Formatted investigation reports ready for court evidence or compliance audits.
- **Interactive UI Workspace**: Responsive dark-mode React interface featuring visual fund flow graph representations, risk meters, and live status progress.

---

## 📁 Repository Structure

```
CryptoTrace/
├── backend/
│   ├── app/
│   │   ├── main.py                     # FastAPI Application Entrypoint
│   │   ├── models/                     # Data Domain Models
│   │   ├── schemas/                    # Pydantic Request/Response Schemas
│   │   ├── repositories/               # Repository Data Layer (db.py)
│   │   ├── providers/                  # Blockchain & Exchange Providers
│   │   ├── services/                   # Business & Forensics Services
│   │   │   ├── wallet_service.py
│   │   │   ├── acquisition_service.py
│   │   │   ├── normalization_service.py
│   │   │   ├── graph_service.py
│   │   │   ├── clustering_service.py
│   │   │   ├── exchange_service.py
│   │   │   ├── risk_service.py
│   │   │   ├── evidence_service.py
│   │   │   ├── monitoring_service.py   # Module 11
│   │   │   ├── report_service.py       # Module 12
│   │   │   └── investigation_orchestrator.py # Module 13
│   │   ├── routes/                     # REST & WS Routes (Module 14)
│   │   └── websocket/                  # WebSocket Connection Manager
│   ├── tests/                          # Backend Test Suite
│   └── requirements.txt
├── frontend/                           # React + Vite Interface (Module 15)
│   ├── src/
│   │   ├── api/                        # API Client (cryptotrace.js)
│   │   ├── components/                 # UI Components (FundFlowGraph, RiskCard, etc.)
│   │   ├── pages/                      # Dashboard, Workspace, Report Pages
│   │   ├── App.jsx
│   │   └── main.jsx
│   └── package.json
├── data/                               # Synthetic Datasets & Intelligence JSONs
├── docs/                               # Architecture & Methodology Documentation
├── docker-compose.yml                  # Docker Container Orchestration
└── README.md
```

---

## 🚀 Quick Start

### Prerequisites
- Python 3.10+
- Node.js 18+

### 1. Backend Setup
```bash
cd backend
python -m venv venv
# On Windows:
venv\Scripts\activate
# On Linux/macOS:
source venv/bin/activate

pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```
Backend API will run at `http://localhost:8000`. Swagger API docs at `http://localhost:8000/docs`.

### 2. Frontend Setup
```bash
cd frontend
npm install
npm run dev
```
Frontend interface will run at `http://localhost:3000` (or `http://localhost:5173`).

---

## 🛡️ License
MIT License. Created for CryptoTrace Blockchain Forensics.
