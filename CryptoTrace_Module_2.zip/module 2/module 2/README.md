# Module 2
## Case & Investigation Management

This is the Module 2 stage of the cumulative CryptoTrace backend.
Later modules extend the same canonical persistence model.
